package main

import (
	"fmt"
	"strconv"
	"strings"
)

// parseExpr recognizes a string literal "..." or a number or a variable name


func parseExpr(token string, vars map[string]Value) (Value, error) {
	token = strings.TrimSpace(token)
	// string literal in double ""
	if len(token) >= 2 && token[0] == '"' && token[len(token)-1] == '"' {
		content := token[1 : len(token)-1]
		content = strings.ReplaceAll(content, `\"`, `"`)
		content = strings.ReplaceAll(content, `\\`, `\`)
		content = strings.ReplaceAll(content, `\n`, "\n")
		return Value{IsNumber: false, Str: content}, nil
	}
	// try number (entire or float)
	if n, err := strconv.ParseFloat(token, 64); err == nil {
		return Value{IsNumber: true, Num: n}, nil
	}
	// if it is referenced variable
	if v, ok := vars[token]; ok {
		return v, nil
	}
	// fallback
	return Value{IsNumber: false, Str: token}, nil
}

func handleAssignment(line string, vars map[string]Value) error {
	parts := strings.SplitN(line, "=", 2)
	if len(parts) != 2 {
		return fmt.Errorf("incorrect assignment syntax")
	}
	lhs := strings.TrimSpace(parts[0])
	rhs := strings.TrimSpace(parts[1])

	if lhs == "" {
		return fmt.Errorf("empty variable name")
	}

	val, err := parseExpr(rhs, vars)
	if err != nil {
		return err
	}
	vars[lhs] = val
	return nil
}

func handleSay(line string, vars map[string]Value) error {
	open := strings.Index(line, "(")
	close := strings.LastIndex(line, ")")
	if open < 0 || close < 0 || close < open {
		return fmt.Errorf("say: chýbajú zátvorky")
	}
	arg := strings.TrimSpace(line[open+1 : close])
	if arg == "" {
		fmt.Println()
		return nil
	}

	val, err := parseExpr(arg, vars)
	if err != nil {
		return err
	}
	fmt.Println(val.String())
	return nil
}
