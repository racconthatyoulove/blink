package main

import (
	"fmt"
	"image"
	"image/jpeg"
	"image/png"
	"math/rand"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/go-gl/gl/v2.1/gl"
	"github.com/go-gl/glfw/v3.3/glfw"
	"golang.org/x/image/font"
	"golang.org/x/image/font/gofont/goregular"
	"golang.org/x/image/font/opentype"
	"golang.org/x/image/math/fixed"
)

// PopElement represents a text element to be displayed in a window
type PopElement struct {
	Name string
	Text string
	Size float64
	X    float64
	Y    float64
}

// Global window storage
var windowDefinitions = make(map[string]map[string]string)
var windowPopElements = make(map[string][]PopElement)
var openWindows = make(map[string]chan bool)
var glfwInitialized = false

// evaluateComparison evaluates comparison expressions (>, <, ==, etc.)
func evaluateComparison(expr string, vars map[string]interface{}) (bool, error) {
	expr = strings.TrimSpace(expr)

	// Check for comparison operators
	compOps := []string{"==", "!=", ">=", "<=", ">", "<"}

	for _, op := range compOps {
		idx := strings.Index(expr, op)
		if idx > 0 && idx < len(expr)-len(op) {
			left := strings.TrimSpace(expr[:idx])
			right := strings.TrimSpace(expr[idx+len(op):])

			// Try to get values directly (avoid recursion)
			var leftResult, rightResult interface{}
			var leftErr, rightErr error

			// Get left value
			if val, ok := vars[left]; ok {
				leftResult = val
			} else if left == "true" || left == "false" {
				leftResult = left == "true"
			} else if len(left) >= 2 && left[0] == '"' && left[len(left)-1] == '"' {
				leftResult = left[1 : len(left)-1]
			} else if val, err := strconv.ParseFloat(left, 64); err == nil {
				leftResult = val
			} else {
				// If it's not a variable, number, or boolean, treat it as a string literal
				leftResult = left
				leftErr = nil
			}

			// Get right value
			if val, ok := vars[right]; ok {
				rightResult = val
			} else if right == "true" || right == "false" {
				rightResult = right == "true"
			} else if len(right) >= 2 && right[0] == '"' && right[len(right)-1] == '"' {
				rightResult = right[1 : len(right)-1]
			} else if val, err := strconv.ParseFloat(right, 64); err == nil {
				rightResult = val
			} else {
				// If it's not a variable, number, or boolean, treat it as a string literal
				rightResult = right
				rightErr = nil
			}

			// If both succeeded, compare the results
			if leftErr == nil && rightErr == nil {
				// Handle different type combinations
				switch leftVal := leftResult.(type) {
				case float64:
					if rightVal, ok := rightResult.(float64); ok {
						switch op {
						case "==":
							return leftVal == rightVal, nil
						case "!=":
							return leftVal != rightVal, nil
						case ">":
							return leftVal > rightVal, nil
						case "<":
							return leftVal < rightVal, nil
						case ">=":
							return leftVal >= rightVal, nil
						case "<=":
							return leftVal <= rightVal, nil
						}
					}
				case string:
					if rightVal, ok := rightResult.(string); ok {
						switch op {
						case "==":
							return leftVal == rightVal, nil
						case "!=":
							return leftVal != rightVal, nil
						}
					}
				case bool:
					if rightVal, ok := rightResult.(bool); ok {
						switch op {
						case "==":
							return leftVal == rightVal, nil
						case "!=":
							return leftVal != rightVal, nil
						}
					}
				}
			}

			// Fallback to numeric comparison
			leftVal, err := getNumericValue(left, vars)
			if err != nil {
				return false, err
			}

			rightVal, err := getNumericValue(right, vars)
			if err != nil {
				return false, err
			}

			switch op {
			case "==":
				return leftVal == rightVal, nil
			case "!=":
				return leftVal != rightVal, nil
			case ">":
				return leftVal > rightVal, nil
			case "<":
				return leftVal < rightVal, nil
			case ">=":
				return leftVal >= rightVal, nil
			case "<=":
				return leftVal <= rightVal, nil
			}
		}
	}

	return false, fmt.Errorf("no comparison operator found in: %s", expr)
}

// evaluateExpression parses and evaluates arithmetic expressions
func evaluateExpression(expr string, vars map[string]interface{}) (interface{}, error) {
	expr = strings.TrimSpace(expr)

	// Handle parentheses - but only if they wrap the entire expression
	if strings.HasPrefix(expr, "(") && strings.HasSuffix(expr, ")") {
		// Check if these parentheses actually wrap the whole expression
		parenCount := 0
		for i, char := range expr {
			if char == '(' {
				parenCount++
			} else if char == ')' {
				parenCount--
				if parenCount == 0 && i < len(expr)-1 {
					// Parentheses closed before the end, so they don't wrap everything
					break
				}
			}
		}
		if parenCount == 0 {
			inner := expr[1 : len(expr)-1]
			return evaluateExpression(inner, vars)
		}
	}

	// Check for comparison operators first (return boolean)
	// But only if they're not inside parentheses and not part of a string concatenation
	compOps := []string{"==", "!=", ">=", "<=", ">", "<"}
	for _, op := range compOps {
		parenCount := 0
		inString := false
		for i := 0; i < len(expr)-len(op)+1; i++ {
			if expr[i] == '"' {
				inString = !inString
			} else if !inString {
				if expr[i] == '(' {
					parenCount++
				} else if expr[i] == ')' {
					parenCount--
				} else if parenCount == 0 && strings.HasPrefix(expr[i:], op) {
					// Found a comparison operator at the top level
					return evaluateComparison(expr, vars)
				}
			}
		}
	}

	// Check for + operator first (could be string concatenation or addition)
	// Find the rightmost + that's not inside parentheses
	parenCount := 0
	plusIdx := -1
	for i := len(expr) - 1; i >= 0; i-- {
		if expr[i] == ')' {
			parenCount++
		} else if expr[i] == '(' {
			parenCount--
		} else if expr[i] == '+' && parenCount == 0 {
			plusIdx = i
			break
		}
	}

	if plusIdx > 0 && plusIdx < len(expr)-1 {
		left := strings.TrimSpace(expr[:plusIdx])
		right := strings.TrimSpace(expr[plusIdx+1:])

		// Recursively evaluate both sides
		leftResult, leftErr := evaluateExpression(left, vars)
		rightResult, rightErr := evaluateExpression(right, vars)

		// If both are numbers, do arithmetic addition
		if leftNum, leftOk := leftResult.(float64); leftOk {
			if rightNum, rightOk := rightResult.(float64); rightOk {
				return leftNum + rightNum, nil
			}
		}

		// Otherwise, do string concatenation
		leftStr := toString(leftResult)
		rightStr := toString(rightResult)

		// Handle errors by falling back to string values
		if leftErr != nil {
			leftStr = getStringValue(left, vars)
		}
		if rightErr != nil {
			rightStr = getStringValue(right, vars)
		}

		return leftStr + rightStr, nil
	}

	// Check for other arithmetic operators
	operators := []string{"*", "/", "-"}

	for _, op := range operators {
		// Find the rightmost occurrence of the operator
		idx := strings.LastIndex(expr, op)
		if idx > 0 && idx < len(expr)-1 {
			left := strings.TrimSpace(expr[:idx])
			right := strings.TrimSpace(expr[idx+1:])

			leftVal, err := getNumericValue(left, vars)
			if err != nil {
				return 0, err
			}

			rightVal, err := getNumericValue(right, vars)
			if err != nil {
				return 0, err
			}

			switch op {
			case "-":
				return leftVal - rightVal, nil
			case "*":
				return leftVal * rightVal, nil
			case "/":
				if rightVal == 0 {
					return 0, fmt.Errorf("division by zero")
				}
				return leftVal / rightVal, nil
			}
		}
	}

	// No operators found, treat as single value
	// Try to get from variables first (could be any type)
	if val, ok := vars[expr]; ok {
		return val, nil
	}

	// Try as number
	if val, err := getNumericValue(expr, vars); err == nil {
		return val, nil
	}
	// Try as string literal or variable
	return getStringValue(expr, vars), nil
}

// toString converts any value to string
func toString(val interface{}) string {
	switch v := val.(type) {
	case string:
		return v
	case float64:
		return fmt.Sprintf("%g", v)
	case bool:
		if v {
			return "true"
		}
		return "false"
	default:
		return fmt.Sprintf("%v", v)
	}
}

// getStringValue gets the string representation of a value
func getStringValue(s string, vars map[string]interface{}) string {
	s = strings.TrimSpace(s)

	// First, try to get from variables (prioritize variables over literals)
	if val, ok := vars[s]; ok {
		return toString(val)
	}

	// String literal
	if len(s) >= 2 && s[0] == '"' && s[len(s)-1] == '"' {
		return s[1 : len(s)-1]
	}

	// Return as-is if not found
	return s
}

// getNumericValue gets the float64 value of a variable or number
func getNumericValue(s string, vars map[string]interface{}) (float64, error) {
	s = strings.TrimSpace(s)

	// First, try to get from variables (prioritize variables over literals)
	if val, ok := vars[s]; ok {
		if floatVal, ok := val.(float64); ok {
			return floatVal, nil
		}
		return 0, fmt.Errorf("variable %s is not a number", s)
	}

	// Skip string literals - they shouldn't be parsed as numbers
	if len(s) >= 2 && s[0] == '"' {
		return 0, fmt.Errorf("cannot convert string literal to number: %s", s)
	}

	// Skip boolean literals - they shouldn't be parsed as numbers
	if s == "true" || s == "false" {
		return 0, fmt.Errorf("cannot convert boolean literal to number: %s", s)
	}

	// If not found as variable, try to parse as float literal
	if val, err := strconv.ParseFloat(s, 64); err == nil {
		return val, nil
	}

	return 0, fmt.Errorf("undefined variable or invalid number: %s", s)
}

// executeBlock executes a block of statements
func executeBlock(lines []string, vars map[string]interface{}) error {
	for i := 0; i < len(lines); i++ {
		line := strings.TrimSpace(lines[i])
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") || line == "}" || line == "} else {" || strings.Contains(line, "} else {") {
			continue
		}

		// Handle nested if statements (NO else support)
		if strings.HasPrefix(line, "if ") {
			// Parse and execute simple if statement
			newI, err := executeSimpleIf(lines, i, vars)
			if err != nil {
				return err
			}
			i = newI
			continue
		}

		// Handle nested loop statements
		if strings.HasPrefix(line, "loop ") {
			// For nested loops, we need to handle them differently
			// Parse the loop count
			loopPart := strings.TrimSpace(line[5:]) // Skip "loop "
			if !strings.HasSuffix(loopPart, "{") {
				return fmt.Errorf("loop statement must end with {")
			}

			countStr := strings.TrimSpace(loopPart[:len(loopPart)-1])

			// Evaluate the loop count
			var loopCount int
			if val, exists := vars[countStr]; exists {
				if floatVal, ok := val.(float64); ok {
					loopCount = int(floatVal)
				} else {
					return fmt.Errorf("loop count variable '%s' is not a number", countStr)
				}
			} else {
				if count, err := strconv.Atoi(countStr); err == nil {
					loopCount = count
				} else {
					return fmt.Errorf("invalid loop count: %s", countStr)
				}
			}

			// Parse the nested loop block
			nestedBlock, newI, err := parseBlock(lines, i+1)
			if err != nil {
				return fmt.Errorf("error parsing nested loop: %s", err)
			}

			// Execute the nested loop
			for iteration := 0; iteration < loopCount; iteration++ {
				// Set the loop variable 'i' to the current iteration number
				vars["i"] = float64(iteration)

				if err := executeBlock(nestedBlock, vars); err != nil {
					return fmt.Errorf("error in nested loop iteration %d: %s", iteration+1, err)
				}
			}

			i = newI
			continue
		}

		// Handle nested ask statements
		if strings.HasPrefix(line, "ask(") {
			// Parse and execute nested ask statement
			newI, err := executeAsk(lines, i, vars)
			if err != nil {
				return fmt.Errorf("error in nested ask: %s", err)
			}
			i = newI
			continue
		}

		// Handle nested random statements
		if strings.HasPrefix(line, "random(") {
			// Parse and execute nested random statement
			newI, err := executeRandom(lines, i, vars)
			if err != nil {
				return fmt.Errorf("error in nested random: %s", err)
			}
			i = newI
			continue
		}

		if err := executeLine(line, vars, i+1); err != nil {
			return err
		}
	}
	return nil
}

// executeLine executes a single line of code
func executeLine(line string, vars map[string]interface{}, lineNo int) error {
	line = strings.TrimSpace(line)

	// Check for remove command first (before assignment parsing)
	if strings.HasPrefix(line, "remove = ") {
		return executeRemoveCommand(line, vars, lineNo)
	}

	// assignment: name = value (but not comparison ==)
	// Find the first = that's not part of a comparison operator
	assignIdx := -1
	for i := 0; i < len(line); i++ {
		if line[i] == '=' {
			// Check if it's part of ==, !=, >=, <=
			if (i > 0 && (line[i-1] == '!' || line[i-1] == '>' || line[i-1] == '<')) ||
				(i < len(line)-1 && line[i+1] == '=') {
				continue // Skip comparison operators
			}
			assignIdx = i
			break
		}
	}

	if assignIdx > 0 {
		name := strings.TrimSpace(line[:assignIdx])
		value := strings.TrimSpace(line[assignIdx+1:])

		// Check if variable already exists (overwrite protection)
		if _, exists := vars[name]; exists {
			return fmt.Errorf("error (line %d): You cannot set new variable \"%s\" because it already exists but here is what you can do if you want to remove the old variable and make new one with same name:\n\nremove = %s\n// and now you can set the variable again:\n%s = <new_value>", lineNo, name, name, name)
		}

		// string literal
		if len(value) >= 2 && value[0] == '"' && value[len(value)-1] == '"' {
			unquoted := value[1 : len(value)-1]
			vars[name] = unquoted
			return nil
		}
		// boolean literal
		if value == "true" || value == "false" {
			vars[name] = value == "true"
			return nil
		}
		// number (float) - only if it's not being assigned to a variable
		if f, err := strconv.ParseFloat(value, 64); err == nil {
			vars[name] = f
			return nil
		}
		// expression
		if result, err := evaluateExpression(value, vars); err == nil {
			vars[name] = result
			return nil
		}
		// fallback: store as raw string (without quotes)
		vars[name] = value
		return nil
	}

	// say(...) -- allow spaces like say(  "x"  )
	re := regexp.MustCompile(`^say\s*\(\s*(.*)\s*\)\s*$`)
	m := re.FindStringSubmatch(line)
	if len(m) == 2 {
		arg := m[1]

		// Always try to evaluate as expression first (handles both arithmetic and string concatenation)
		if strings.ContainsAny(arg, "+-*/") {
			result, err := evaluateExpression(arg, vars)
			if err != nil {
				// If expression evaluation fails and it's a simple string literal, treat as string
				if len(arg) >= 2 && arg[0] == '"' && arg[len(arg)-1] == '"' {
					fmt.Println(arg[1 : len(arg)-1])
					return nil
				}
				return fmt.Errorf("error (line %d): %s", lineNo, err)
			}
			fmt.Println(result)
			return nil
		}

		// string literal
		if len(arg) >= 2 && arg[0] == '"' && arg[len(arg)-1] == '"' {
			fmt.Println(arg[1 : len(arg)-1])
			return nil
		}

		// identifier: must exist
		if val, ok := vars[arg]; ok {
			fmt.Println(val)
		} else {
			return fmt.Errorf("error (line %d): undefined variable %s", lineNo, arg)
		}
		return nil
	}

	// wait command: wait <duration>
	if strings.HasPrefix(line, "wait ") {
		durationStr := strings.TrimSpace(line[5:])
		if duration, err := strconv.ParseFloat(durationStr, 64); err == nil {
			time.Sleep(time.Duration(duration * float64(time.Second)))
			return nil
		} else {
			return fmt.Errorf("error (line %d): invalid wait duration: %s", lineNo, durationStr)
		}
	}

	return fmt.Errorf("error (line %d): unknown statement: %s", lineNo, line)
}

// executeRemoveCommand handles the remove command for variables and future extensibility
func executeRemoveCommand(line string, vars map[string]interface{}, lineNo int) error {
	// Extract the items to remove after "remove = "
	itemsStr := strings.TrimSpace(line[9:]) // Skip "remove = "

	if itemsStr == "" {
		return fmt.Errorf("error (line %d): remove command requires at least one item to remove", lineNo)
	}

	// Split by comma and process each item
	items := strings.Split(itemsStr, ",")
	removedItems := []string{}
	removedWindows := []string{}
	notFoundItems := []string{}

	for _, item := range items {
		item = strings.TrimSpace(item)
		if item == "" {
			continue
		}

		// Check if this is a window removal (window.name syntax)
		if strings.HasPrefix(item, "window.") {
			windowName := strings.TrimPrefix(item, "window.")
			if err := removeWindow(windowName); err != nil {
				// For windows, we want to show the specific error message immediately
				fmt.Printf("Error: %s\n", err.Error())
				notFoundItems = append(notFoundItems, item)
			} else {
				removedWindows = append(removedWindows, windowName)
			}
		} else {
			// Regular variable removal
			if err := removeVariable(item, vars); err != nil {
				notFoundItems = append(notFoundItems, item)
			} else {
				removedItems = append(removedItems, item)
			}
		}
	}

	// Provide feedback about what was removed
	if len(removedItems) > 0 {
		fmt.Printf("Removed variables: %s\n", strings.Join(removedItems, ", "))
	}

	if len(removedWindows) > 0 {
		fmt.Printf("Removed windows: %s\n", strings.Join(removedWindows, ", "))
	}

	if len(notFoundItems) > 0 {
		return fmt.Errorf("error (line %d): cannot remove non-existent items: %s", lineNo, strings.Join(notFoundItems, ", "))
	}

	return nil
}

// removeVariable removes a variable from the variables map
// This function is designed to be extensible for future removal types
func removeVariable(name string, vars map[string]interface{}) error {
	if _, exists := vars[name]; !exists {
		return fmt.Errorf("variable %s does not exist", name)
	}

	delete(vars, name)
	return nil
}

// removeWindow removes a window definition from the window definitions map
func removeWindow(windowName string) error {
	if _, exists := windowDefinitions[windowName]; !exists {
		return fmt.Errorf("window %s does not exist", windowName)
	}

	// Check if the window is currently open
	if _, isOpen := openWindows[windowName]; isOpen {
		return fmt.Errorf("cannot remove window %s: window is currently open, close it first", windowName)
	}

	delete(windowDefinitions, windowName)
	// Also remove pop elements for this window
	delete(windowPopElements, windowName)
	return nil
}

// executeLoop executes a loop statement with specified iterations
func executeLoop(lines []string, startIdx int, vars map[string]interface{}) (int, error) {
	i := startIdx

	// Parse loop statement
	line := strings.TrimSpace(lines[i])
	if !strings.HasPrefix(line, "loop ") {
		return i, fmt.Errorf("expected loop statement")
	}

	// Parse loop count and opening brace
	loopPart := strings.TrimSpace(line[5:]) // Skip "loop "
	if !strings.HasSuffix(loopPart, "{") {
		return i, fmt.Errorf("error (line %d): loop statement must end with {", i+1)
	}

	// Extract the loop count
	countStr := strings.TrimSpace(loopPart[:len(loopPart)-1])

	// Evaluate the loop count (could be a variable or number)
	var loopCount int
	if val, exists := vars[countStr]; exists {
		// Try to convert variable to number
		if floatVal, ok := val.(float64); ok {
			loopCount = int(floatVal)
		} else {
			return i, fmt.Errorf("error (line %d): loop count variable '%s' is not a number", i+1, countStr)
		}
	} else {
		// Try to parse as number literal
		if count, err := strconv.Atoi(countStr); err == nil {
			loopCount = count
		} else {
			return i, fmt.Errorf("error (line %d): invalid loop count: %s", i+1, countStr)
		}
	}

	if loopCount < 0 {
		return i, fmt.Errorf("error (line %d): loop count cannot be negative: %d", i+1, loopCount)
	}

	// Parse loop block
	loopBlock, nextI, err := parseBlock(lines, i+1)
	if err != nil {
		return i, fmt.Errorf("error (line %d): %s", i+1, err)
	}

	// Execute the loop block the specified number of times
	for iteration := 0; iteration < loopCount; iteration++ {
		// Set the loop variable 'i' to the current iteration number
		vars["i"] = float64(iteration)

		// Create a copy of the loop block for each iteration to avoid line number conflicts
		blockCopy := make([]string, len(loopBlock))
		copy(blockCopy, loopBlock)

		if err := executeBlock(blockCopy, vars); err != nil {
			return i, fmt.Errorf("error in loop iteration %d: %s", iteration+1, err)
		}
	}

	return nextI, nil
}

// executeAsk executes an ask statement with user input
func executeAsk(lines []string, startIdx int, vars map[string]interface{}) (int, error) {
	i := startIdx

	// Parse ask statement
	line := strings.TrimSpace(lines[i])
	if !strings.HasPrefix(line, "ask(") {
		return i, fmt.Errorf("expected ask statement")
	}

	// Extract the question from ask("question"){
	questionStart := strings.Index(line, "ask(") + 4
	questionEnd := strings.Index(line[questionStart:], ")") + questionStart
	if questionEnd <= questionStart {
		return i, fmt.Errorf("error (line %d): malformed ask statement", i+1)
	}

	question := line[questionStart:questionEnd]

	// Remove quotes from question if present
	if len(question) >= 2 && question[0] == '"' && question[len(question)-1] == '"' {
		question = question[1 : len(question)-1]
	}

	// Check for opening brace
	if !strings.Contains(line, "{") {
		return i, fmt.Errorf("error (line %d): ask statement must end with {", i+1)
	}

	// Display the question and get user input
	fmt.Println(question)
	fmt.Print("> ")
	var userInput string
	fmt.Scanln(&userInput)

	// Set the answer variable
	vars["answer"] = userInput

	// Parse ask block
	askBlock, nextI, err := parseBlock(lines, i+1)
	if err != nil {
		return i, fmt.Errorf("error (line %d): %s", i+1, err)
	}

	// Execute the ask block
	if err := executeBlock(askBlock, vars); err != nil {
		return i, fmt.Errorf("error in ask block: %s", err)
	}

	return nextI, nil
}

// executeRandom executes a random statement with random selection
func executeRandom(lines []string, startIdx int, vars map[string]interface{}) (int, error) {
	i := startIdx

	// Parse random statement
	line := strings.TrimSpace(lines[i])
	if !strings.HasPrefix(line, "random(") {
		return i, fmt.Errorf("expected random statement")
	}

	// Extract the options from random(option1, option2, ...){
	optionsStart := strings.Index(line, "random(") + 7
	optionsEnd := strings.Index(line[optionsStart:], ")") + optionsStart
	if optionsEnd <= optionsStart {
		return i, fmt.Errorf("error (line %d): malformed random statement", i+1)
	}

	optionsStr := line[optionsStart:optionsEnd]

	// Parse options by splitting on commas
	var options []string
	if strings.TrimSpace(optionsStr) != "" {
		rawOptions := strings.Split(optionsStr, ",")
		for _, option := range rawOptions {
			trimmed := strings.TrimSpace(option)
			if trimmed != "" {
				options = append(options, trimmed)
			}
		}
	}

	if len(options) == 0 {
		return i, fmt.Errorf("error (line %d): random statement must have at least one option", i+1)
	}

	// Check for opening brace
	if !strings.Contains(line, "{") {
		return i, fmt.Errorf("error (line %d): random statement must end with {", i+1)
	}

	// Randomly select one option
	randomIndex := rand.Intn(len(options))
	selectedOption := options[randomIndex]

	// Set the chosen variable
	vars["chosen"] = selectedOption

	// Parse random block
	randomBlock, nextI, err := parseBlock(lines, i+1)
	if err != nil {
		return i, fmt.Errorf("error (line %d): %s", i+1, err)
	}

	// Execute the random block
	if err := executeBlock(randomBlock, vars); err != nil {
		return i, fmt.Errorf("error in random block: %s", err)
	}

	return nextI, nil
}

// executeWindowDefine handles window definition: window name { }
func executeWindowDefine(line string) error {
	// Parse: window name {
	parts := strings.Fields(line)
	if len(parts) < 2 {
		return fmt.Errorf("invalid window definition syntax")
	}

	windowName := parts[1]

	// For now, just store an empty parameter map
	// In the future, this can be extended to parse actual parameters
	windowDefinitions[windowName] = make(map[string]string)

	return nil
}

// executeWindowOpen handles window open command: window open name
func executeWindowOpen(line string) error {
	// Parse: window open name
	parts := strings.Fields(line)
	if len(parts) < 3 {
		return fmt.Errorf("invalid window open syntax")
	}

	windowName := parts[2]

	// Check if window is defined
	windowDef, exists := windowDefinitions[windowName]
	if !exists {
		return fmt.Errorf("window '%s' is not defined", windowName)
	}

	// Get the display name for the window (default to windowName if not specified)
	displayName := windowDef["name"]
	if displayName == "" {
		displayName = windowName
	}

	// Get the size for the window (default to 400x300 if not specified)
	windowSize := windowDef["size"]
	width, height := 400, 300 // Default size
	isFullscreen := false
	isEntirescreen := false

	// Get the resize parameter (default to true if not specified)
	resizeParam := windowDef["resize"]
	isResizable := true // Default to resizable
	if resizeParam != "" {
		if strings.TrimSpace(resizeParam) == "false" {
			isResizable = false
		} else if strings.TrimSpace(resizeParam) == "true" {
			isResizable = true
		}
		// If it's not "true" or "false", default to true
	}

	// Get the triangle parameter (default to false if not specified)
	triangleParam := windowDef["triangle"]
	hasTriangle := false // Default to no triangle
	if triangleParam != "" {
		if strings.TrimSpace(triangleParam) == "true" {
			hasTriangle = true
		} else if strings.TrimSpace(triangleParam) == "false" {
			hasTriangle = false
		}
		// If it's not "true" or "false", default to false
	}

	// Get the grid parameter (default to false if not specified)
	gridParam := windowDef["grid"]
	hasGrid := false // Default to no grid
	if gridParam != "" {
		if strings.TrimSpace(gridParam) == "true" {
			hasGrid = true
		} else if strings.TrimSpace(gridParam) == "false" {
			hasGrid = false
		}
		// If it's not "true" or "false", default to false
	}

	// Get the color parameter (default to black if not specified)
	colorParam := windowDef["color"]
	bgRed, bgGreen, bgBlue := float32(0.0), float32(0.0), float32(0.0) // Default to black
	if colorParam != "" {
		// Parse hex color (with or without #)
		hexColor := strings.TrimSpace(colorParam)
		if strings.HasPrefix(hexColor, "#") {
			hexColor = hexColor[1:] // Remove # if present
		}

		// Parse RGB values from hex
		if len(hexColor) == 6 {
			if r, err := strconv.ParseInt(hexColor[0:2], 16, 64); err == nil {
				if g, err := strconv.ParseInt(hexColor[2:4], 16, 64); err == nil {
					if b, err := strconv.ParseInt(hexColor[4:6], 16, 64); err == nil {
						bgRed = float32(r) / 255.0
						bgGreen = float32(g) / 255.0
						bgBlue = float32(b) / 255.0
					}
				}
			}
		}
		// If parsing fails, keep default black color
	}

	// Get the icon parameter (default to empty if not specified)
	iconParam := windowDef["icon"]
	iconPath := ""
	if iconParam != "" {
		iconPath = strings.TrimSpace(iconParam)
		// Convert relative path to absolute path if needed
		if !strings.HasPrefix(iconPath, "/") {
			// For relative paths, make them relative to the blink directory
			iconPath = "blink/" + iconPath
		}
	}

	// Get the selector parameter (default to false if not specified)
	selectorParam := windowDef["selector"]
	hasSelector := false // Default to no coordinate selector
	if selectorParam != "" {
		if strings.TrimSpace(selectorParam) == "true" {
			hasSelector = true
		} else if strings.TrimSpace(selectorParam) == "false" {
			hasSelector = false
		}
		// If it's not "true" or "false", default to false
	}

	// Get the cursor parameter (default to true - show cursor)
	cursorParam := windowDef["cursor"]
	showCursor := true // Default to showing cursor
	if cursorParam != "" {
		if strings.TrimSpace(cursorParam) == "false" {
			showCursor = false
		} else if strings.TrimSpace(cursorParam) == "true" {
			showCursor = true
		}
		// If it's not "true" or "false", default to true
	}

	// Get the transparency parameter (default to 1.0 - fully opaque)
	transparencyParam := windowDef["transparency"]
	transparency := 1.0 // Default to fully opaque
	if transparencyParam != "" {
		if t, err := strconv.ParseFloat(strings.TrimSpace(transparencyParam), 64); err == nil {
			// Clamp transparency between 0.0 and 1.0
			if t < 0.0 {
				transparency = 0.0
			} else if t > 1.0 {
				transparency = 1.0
			} else {
				transparency = t
			}
		}
		// If parsing fails, keep default 1.0
	}

	// Get the always_on_top parameter (default to false)
	alwaysOnTopParam := windowDef["always_on_top"]
	alwaysOnTop := false // Default to normal window behavior
	if alwaysOnTopParam != "" {
		if strings.TrimSpace(alwaysOnTopParam) == "true" {
			alwaysOnTop = true
		} else if strings.TrimSpace(alwaysOnTopParam) == "false" {
			alwaysOnTop = false
		}
		// If it's not "true" or "false", default to false
	}

	// Get the background image parameter (default to empty)
	imageParam := windowDef["image"]
	imagePath := ""
	if imageParam != "" {
		imagePath = strings.TrimSpace(imageParam)
		// Convert relative path to absolute path if needed
		if !strings.HasPrefix(imagePath, "/") {
			// For relative paths, make them relative to the blink directory
			imagePath = "blink/" + imagePath
		}
	}

	if windowSize != "" {
		// Check for special fullscreen modes
		if strings.TrimSpace(windowSize) == "fullscreen" {
			isFullscreen = true
			// Screen dimensions will be set inside the goroutine after GLFW init
		} else if strings.TrimSpace(windowSize) == "entirescreen" {
			isEntirescreen = true
			// Screen dimensions will be set inside the goroutine after GLFW init
		} else if strings.Contains(windowSize, "x") {
			// Parse size format like "600x500"
			parts := strings.Split(windowSize, "x")
			if len(parts) == 2 {
				if w, err := strconv.Atoi(strings.TrimSpace(parts[0])); err == nil {
					if h, err := strconv.Atoi(strings.TrimSpace(parts[1])); err == nil {
						width, height = w, h
					}
				}
			}
		}
	}

	// Check if window is already open
	if _, exists := openWindows[windowName]; exists {
		return fmt.Errorf("window '%s' is already open", windowName)
	}

	// Create a channel to control the window
	closeChan := make(chan bool, 1)
	openWindows[windowName] = closeChan

	// Print feedback that window is being opened
	fmt.Printf("✓ Opening window '%s'...\n", windowName)

	// Create and show the actual window in a goroutine
	go func(windowName, displayName string, windowWidth, windowHeight int, fullscreen, entirescreen, resizable, triangle, grid bool, red, green, blue float32, iconPath string, selector bool, cursor bool, windowTransparency float64, onTop bool, backgroundImagePath string) {
		defer func() {
			// Clean up when function exits
			delete(openWindows, windowName)
			fmt.Printf("✓ Window '%s' closed.\n", windowName)
		}()

		// Initialize GLFW only once globally
		if !glfwInitialized {
			if err := glfw.Init(); err != nil {
				fmt.Printf("Failed to initialize GLFW: %v\n", err)
				return
			}
			glfwInitialized = true
		}

		// Get screen dimensions for fullscreen modes after GLFW is initialized
		if fullscreen || entirescreen {
			vidMode := glfw.GetPrimaryMonitor().GetVideoMode()
			windowWidth, windowHeight = vidMode.Width, vidMode.Height
		}

		// Set basic OpenGL context hints
		glfw.WindowHint(glfw.ContextVersionMajor, 2)
		glfw.WindowHint(glfw.ContextVersionMinor, 1)

		// Set window resizable hint
		if resizable {
			glfw.WindowHint(glfw.Resizable, glfw.True)
		} else {
			glfw.WindowHint(glfw.Resizable, glfw.False)
		}

		// Create window with specified size or fullscreen mode
		var monitor *glfw.Monitor
		if entirescreen {
			// Entirescreen mode - exclusive fullscreen
			monitor = glfw.GetPrimaryMonitor()
		}
		// For fullscreen mode, we create a windowed window and maximize it after creation

		window, err := glfw.CreateWindow(windowWidth, windowHeight, displayName, monitor, nil)
		if err != nil {
			fmt.Printf("Failed to create window: %v\n", err)
			return
		}
		defer window.Destroy()

		// Set minimum window size for better user experience
		window.SetSizeLimits(200, 150, glfw.DontCare, glfw.DontCare)

		// Load and set window icon if specified
		if iconPath != "" {
			loadWindowIcon(window, iconPath)
		}

		// Set up coordinate selector if enabled
		if selector {
			fmt.Printf("✓ Coordinate selector enabled for '%s' - Right-click to get coordinates\n", windowName)
			window.SetMouseButtonCallback(func(w *glfw.Window, button glfw.MouseButton, action glfw.Action, mods glfw.ModifierKey) {
				if button == glfw.MouseButtonRight && action == glfw.Press {
					// Get cursor position
					xpos, ypos := w.GetCursorPos()
					// Convert to integer coordinates
					x := int(xpos)
					y := int(ypos)
					// Print coordinates in the requested format
					fmt.Printf("Coords are:\n   x = %d\n   y = %d\n", x, y)
				}
			})
		}

		// Set cursor visibility
		if !cursor {
			window.SetInputMode(glfw.CursorMode, glfw.CursorHidden)
			fmt.Printf("✓ Cursor hidden for '%s'\n", windowName)
		} else {
			window.SetInputMode(glfw.CursorMode, glfw.CursorNormal)
		}

		// Set window transparency
		if windowTransparency < 1.0 {
			window.SetOpacity(float32(windowTransparency))
			fmt.Printf("✓ Transparency set to %.1f for '%s'\n", windowTransparency, windowName)
		}

		// Set always on top
		if onTop {
			window.SetAttrib(glfw.Floating, glfw.True)
			fmt.Printf("✓ Always on top enabled for '%s'\n", windowName)
		}

		// Handle window positioning and fullscreen modes
		if fullscreen {
			// Fullscreen mode - maximize the window
			window.Maximize()
		} else if !entirescreen {
			// Normal windowed mode - center the window
			vidMode := glfw.GetPrimaryMonitor().GetVideoMode()
			window.SetPos((vidMode.Width-windowWidth)/2, (vidMode.Height-windowHeight)/2)
		}
		// For entirescreen mode, positioning is handled automatically by GLFW

		// Make the OpenGL context current
		window.MakeContextCurrent()

		// Initialize OpenGL
		if err := gl.Init(); err != nil {
			fmt.Printf("Failed to initialize OpenGL: %v\n", err)
			return
		}

		// Disable VSync and use manual frame limiting instead
		glfw.SwapInterval(0) // Disable VSync (can cause glitching on some systems)

		// Set up initial OpenGL state for 2D rendering
		gl.Enable(gl.BLEND)
		gl.BlendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)
		gl.Disable(gl.DEPTH_TEST)

		// Set up initial projection matrix
		gl.MatrixMode(gl.PROJECTION)
		gl.LoadIdentity()
		gl.Ortho(-1, 1, -1, 1, -1, 1)

		// Set up initial model-view matrix
		gl.MatrixMode(gl.MODELVIEW)
		gl.LoadIdentity()

		// Load background image if specified
		var backgroundImage *image.RGBA
		if backgroundImagePath != "" {
			var err error
			backgroundImage, err = loadBackgroundImage(backgroundImagePath)
			if err != nil {
				fmt.Printf("Warning: Failed to load background image '%s': %v\n", backgroundImagePath, err)
				backgroundImage = nil
			} else {
				fmt.Printf("✓ Background image loaded successfully: %s\n", backgroundImagePath)
			}
		}

		fmt.Printf("✓ Window '%s' opened successfully\n", windowName)

		// Frame rate limiting
		targetFPS := 60.0
		frameTime := time.Duration(1000/targetFPS) * time.Millisecond

		// Main window loop
		for !window.ShouldClose() {
			// Check for close signal
			select {
			case <-closeChan:
				window.SetShouldClose(true)
				return
			default:
			}

			// Set viewport to current window size
			width, height := window.GetSize()
			gl.Viewport(0, 0, int32(width), int32(height))

			// Set up proper projection matrix for 2D rendering
			gl.MatrixMode(gl.PROJECTION)
			gl.LoadIdentity()
			gl.Ortho(-1, 1, -1, 1, -1, 1) // Normalized device coordinates

			// Set up model-view matrix
			gl.MatrixMode(gl.MODELVIEW)
			gl.LoadIdentity()

			// Clear the screen with background color
			gl.ClearColor(bgRed, bgGreen, bgBlue, 1.0)
			gl.Clear(gl.COLOR_BUFFER_BIT)

			// Draw background image if loaded (behind everything else)
			if backgroundImage != nil {
				renderBackgroundImageSimple(backgroundImage, width, height)
			}

			// Draw grid if enabled (behind triangle)
			if grid {
				drawGrid(width, height)
			}

			// Draw triangle if enabled (in front of grid)
			if triangle {
				drawTriangle(width, height)
			}

			// Draw pop elements (text) if any exist for this window
			if popElements, exists := windowPopElements[windowName]; exists {
				for _, popElement := range popElements {
					// Use original coordinates and size - let OpenGL handle the scaling
					// This avoids expensive recalculations every frame
					renderTextOptimized(popElement.Text, popElement.X, popElement.Y, popElement.Size, 1100, 700, width, height)
				}
			}

			// Poll events
			glfw.PollEvents()

			// Swap buffers
			window.SwapBuffers()

			// Frame rate limiting
			time.Sleep(frameTime)
		}
	}(windowName, displayName, width, height, isFullscreen, isEntirescreen, isResizable, hasTriangle, hasGrid, bgRed, bgGreen, bgBlue, iconPath, hasSelector, showCursor, transparency, alwaysOnTop, imagePath)

	// Give the window a moment to start
	time.Sleep(200 * time.Millisecond)

	return nil
}

// executeWindowClose handles window close command: window close name
func executeWindowClose(line string) error {
	// Parse: window close name
	parts := strings.Fields(line)
	if len(parts) < 3 {
		return fmt.Errorf("invalid window close syntax")
	}

	windowName := parts[2]

	// Check if window is open
	if closeChan, exists := openWindows[windowName]; exists {
		fmt.Printf("✓ Closing window '%s'...\n", windowName)
		// Send close signal
		select {
		case closeChan <- true:
		default:
		}
		return nil
	}

	return fmt.Errorf("window '%s' is not open", windowName)
}

// loadWindowIcon loads an image file and sets it as the window icon
func loadWindowIcon(window *glfw.Window, iconPath string) {
	if iconPath == "" {
		return // No icon specified
	}

	// Check if file exists
	if _, err := os.Stat(iconPath); os.IsNotExist(err) {
		fmt.Printf("Warning: Icon file not found: %s\n", iconPath)
		return
	}

	// Open the image file
	file, err := os.Open(iconPath)
	if err != nil {
		fmt.Printf("Warning: Failed to open icon file: %v\n", err)
		return
	}
	defer file.Close()

	// Decode the image based on file extension
	var img image.Image
	ext := strings.ToLower(iconPath)
	if strings.HasSuffix(ext, ".png") {
		img, err = png.Decode(file)
	} else if strings.HasSuffix(ext, ".jpg") || strings.HasSuffix(ext, ".jpeg") {
		img, err = jpeg.Decode(file)
	} else {
		fmt.Printf("Warning: Unsupported icon format. Use PNG or JPG.\n")
		return
	}

	if err != nil {
		fmt.Printf("Warning: Failed to decode icon image: %v\n", err)
		return
	}

	// Get image dimensions
	bounds := img.Bounds()
	width := bounds.Dx()
	height := bounds.Dy()

	// Convert image to RGBA format for GLFW
	rgba := make([]uint8, width*height*4)
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			r, g, b, a := img.At(x, y).RGBA()
			idx := (y*width + x) * 4
			rgba[idx] = uint8(r >> 8)
			rgba[idx+1] = uint8(g >> 8)
			rgba[idx+2] = uint8(b >> 8)
			rgba[idx+3] = uint8(a >> 8)
		}
	}

	// Create GLFW image struct and set as window icon
	// This should work on Windows, macOS, and Linux (X11)
	defer func() {
		if r := recover(); r != nil {
			fmt.Printf("Warning: Could not set window icon: %v\n", r)
		}
	}()

	// Create RGBA image from our data
	rgbaImg := image.NewRGBA(image.Rect(0, 0, width, height))
	copy(rgbaImg.Pix, rgba)

	// Set the window icon using GLFW - pass as slice of images
	// Note: On some Linux systems (Wayland), this may be ignored by the window manager
	window.SetIcon([]image.Image{rgbaImg})
	fmt.Printf("✓ Icon set successfully: %s (%dx%d)\n", iconPath, width, height)
}

// drawGrid renders a grid overlay that scales with the window size
func drawGrid(windowWidth, windowHeight int) {
	// Calculate grid parameters based on window size
	gridSize := 50 // Base grid cell size in pixels

	// Adjust grid size based on window dimensions to keep it proportional
	minDimension := windowWidth
	if windowHeight < windowWidth {
		minDimension = windowHeight
	}

	// Scale grid size based on window size (between 20 and 80 pixels)
	gridSize = minDimension / 15
	if gridSize < 20 {
		gridSize = 20
	}
	if gridSize > 80 {
		gridSize = 80
	}

	// Set grid line color (semi-transparent white)
	gl.Color4f(1.0, 1.0, 1.0, 0.3) // White with 30% opacity

	// Draw vertical lines
	gl.Begin(gl.LINES)
	for x := gridSize; x < windowWidth; x += gridSize {
		// Convert to normalized device coordinates
		xNorm := (float32(x)/float32(windowWidth))*2.0 - 1.0
		gl.Vertex2f(xNorm, -1.0) // Bottom
		gl.Vertex2f(xNorm, 1.0)  // Top
	}

	// Draw horizontal lines
	for y := gridSize; y < windowHeight; y += gridSize {
		// Convert to normalized device coordinates
		yNorm := (float32(y)/float32(windowHeight))*2.0 - 1.0
		gl.Vertex2f(-1.0, yNorm) // Left
		gl.Vertex2f(1.0, yNorm)  // Right
	}
	gl.End()
}

// drawTriangle renders a triangle that scales with the window size
func drawTriangle(windowWidth, windowHeight int) {
	// Calculate triangle vertices based on window size
	// Triangle will be centered and scale with window dimensions
	centerX := float32(windowWidth) / 2.0
	centerY := float32(windowHeight) / 2.0

	// Scale factor based on smaller dimension to keep triangle proportional
	scale := float32(windowWidth)
	if windowHeight < windowWidth {
		scale = float32(windowHeight)
	}
	scale *= 0.3 // Make triangle 30% of window size

	// Triangle vertices (normalized device coordinates)
	// Top vertex
	x1 := (centerX)/float32(windowWidth)*2.0 - 1.0
	y1 := (centerY+scale/2)/float32(windowHeight)*2.0 - 1.0

	// Bottom left vertex
	x2 := (centerX-scale/2)/float32(windowWidth)*2.0 - 1.0
	y2 := (centerY-scale/2)/float32(windowHeight)*2.0 - 1.0

	// Bottom right vertex
	x3 := (centerX+scale/2)/float32(windowWidth)*2.0 - 1.0
	y3 := (centerY-scale/2)/float32(windowHeight)*2.0 - 1.0

	// Draw triangle using immediate mode (simple approach)
	gl.Begin(gl.TRIANGLES)
	gl.Color3f(1.0, 0.0, 0.0) // Red color
	gl.Vertex2f(x1, y1)       // Top vertex
	gl.Color3f(0.0, 1.0, 0.0) // Green color
	gl.Vertex2f(x2, y2)       // Bottom left vertex
	gl.Color3f(0.0, 0.0, 1.0) // Blue color
	gl.Vertex2f(x3, y3)       // Bottom right vertex
	gl.End()
}

// renderText renders text at the specified position with the given size using proper font rendering
// The x,y coordinates represent the CENTER/MIDDLE of the text
func renderText(text string, x, y float64, size float64, windowWidth, windowHeight int) {
	// Scale size relative to window size (size 100 = full window height)
	scaleFactor := size / 10.0 // Base scale factor
	if scaleFactor < 0.5 {
		scaleFactor = 0.5 // Minimum readable scale
	}

	// Parse the Go regular font (similar to Roboto)
	ttf, err := opentype.Parse(goregular.TTF)
	if err != nil {
		// Fallback to simple character rendering if font parsing fails
		renderTextWithCharacters(text, x, y, size, windowWidth, windowHeight)
		return
	}

	// Create font face with proper size
	fontSize := size * float64(windowHeight) / 100.0
	if fontSize < 8 {
		fontSize = 8
	}

	face, err := opentype.NewFace(ttf, &opentype.FaceOptions{
		Size: fontSize,
		DPI:  72,
	})
	if err != nil {
		// Fallback if face creation fails
		renderTextWithCharacters(text, x, y, size, windowWidth, windowHeight)
		return
	}
	defer face.Close()

	// Calculate text dimensions for proper sizing
	bounds, _ := font.BoundString(face, text)
	textWidth := (bounds.Max.X - bounds.Min.X).Ceil()
	textHeight := (bounds.Max.Y - bounds.Min.Y).Ceil()

	// Add padding to avoid clipping
	padding := 10
	imgWidth := textWidth + padding*2
	imgHeight := textHeight + padding*2

	// Ensure minimum size
	if imgWidth < 50 {
		imgWidth = 50
	}
	if imgHeight < 30 {
		imgHeight = 30
	}

	// Create an image sized to fit the text (not full screen)
	textImg := image.NewRGBA(image.Rect(0, 0, imgWidth, imgHeight))

	// Create a font drawer - position text within the smaller image
	d := &font.Drawer{
		Dst:  textImg,
		Src:  image.White, // White text
		Face: face,
		Dot:  fixed.Point26_6{X: fixed.I(padding), Y: fixed.I(textHeight + padding/2)},
	}

	// Draw the text
	d.DrawString(text)

	// Convert the text image to OpenGL texture and render it at the specified position
	renderTextImageAtPosition(textImg, x, y, float64(imgWidth), float64(imgHeight), windowWidth, windowHeight)
}

// renderTextWithCharacters provides fallback character-based rendering
func renderTextWithCharacters(text string, x, y, size float64, windowWidth, windowHeight int) {
	// Convert to OpenGL coordinates
	glX := (x/float64(windowWidth))*2.0 - 1.0
	glY := 1.0 - (y/float64(windowHeight))*2.0

	// Use the character-based rendering system
	renderSimpleText(text, glX, glY, size/100.0)
}

// renderTextImageAtPosition renders an image containing text to OpenGL at a specific position
func renderTextImageAtPosition(img *image.RGBA, centerX, centerY, imgWidth, imgHeight float64, windowWidth, windowHeight int) {
	// Enable texturing
	gl.Enable(gl.TEXTURE_2D)

	// Generate texture
	var textureID uint32
	gl.GenTextures(1, &textureID)
	gl.BindTexture(gl.TEXTURE_2D, textureID)

	// Set texture parameters
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)

	// Upload texture data
	gl.TexImage2D(gl.TEXTURE_2D, 0, gl.RGBA, int32(imgWidth), int32(imgHeight), 0, gl.RGBA, gl.UNSIGNED_BYTE, gl.Ptr(img.Pix))

	// Set color to white with some transparency for blending
	gl.Color4f(1.0, 1.0, 1.0, 1.0)

	// Enable blending for transparent text background
	gl.Enable(gl.BLEND)
	gl.BlendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)

	// Convert screen coordinates to OpenGL coordinates
	// Calculate the quad position centered at the specified coordinates
	halfWidth := imgWidth / 2.0
	halfHeight := imgHeight / 2.0

	// Convert to normalized device coordinates (-1 to 1)
	left := ((centerX-halfWidth)/float64(windowWidth))*2.0 - 1.0
	right := ((centerX+halfWidth)/float64(windowWidth))*2.0 - 1.0
	bottom := 1.0 - ((centerY+halfHeight)/float64(windowHeight))*2.0
	top := 1.0 - ((centerY-halfHeight)/float64(windowHeight))*2.0

	// Render a positioned quad with the texture
	gl.Begin(gl.QUADS)
	gl.TexCoord2f(0, 1)
	gl.Vertex2f(float32(left), float32(bottom)) // Bottom-left
	gl.TexCoord2f(1, 1)
	gl.Vertex2f(float32(right), float32(bottom)) // Bottom-right
	gl.TexCoord2f(1, 0)
	gl.Vertex2f(float32(right), float32(top)) // Top-right
	gl.TexCoord2f(0, 0)
	gl.Vertex2f(float32(left), float32(top)) // Top-left
	gl.End()

	// Clean up
	gl.Disable(gl.BLEND)
	gl.Disable(gl.TEXTURE_2D)
	gl.DeleteTextures(1, &textureID)
}

// renderTextImage renders an image containing text to OpenGL (legacy full-screen version)
func renderTextImage(img *image.RGBA, windowWidth, windowHeight int) {
	// Enable texturing
	gl.Enable(gl.TEXTURE_2D)

	// Generate texture
	var textureID uint32
	gl.GenTextures(1, &textureID)
	gl.BindTexture(gl.TEXTURE_2D, textureID)

	// Set texture parameters
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)

	// Upload texture data
	gl.TexImage2D(gl.TEXTURE_2D, 0, gl.RGBA, int32(windowWidth), int32(windowHeight), 0, gl.RGBA, gl.UNSIGNED_BYTE, gl.Ptr(img.Pix))

	// Set color to white with some transparency for blending
	gl.Color4f(1.0, 1.0, 1.0, 1.0)

	// Enable blending for transparent text background
	gl.Enable(gl.BLEND)
	gl.BlendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)

	// Render a full-screen quad with the texture
	gl.Begin(gl.QUADS)
	gl.TexCoord2f(0, 1)
	gl.Vertex2f(-1, -1) // Bottom-left
	gl.TexCoord2f(1, 1)
	gl.Vertex2f(1, -1) // Bottom-right
	gl.TexCoord2f(1, 0)
	gl.Vertex2f(1, 1) // Top-right
	gl.TexCoord2f(0, 0)
	gl.Vertex2f(-1, 1) // Top-left
	gl.End()

	// Clean up
	gl.Disable(gl.BLEND)
	gl.Disable(gl.TEXTURE_2D)
	gl.DeleteTextures(1, &textureID)
}

// loadBackgroundImage loads an image file and returns the image data
func loadBackgroundImage(imagePath string) (*image.RGBA, error) {
	if imagePath == "" {
		return nil, nil // No image specified
	}

	// Open the image file
	file, err := os.Open(imagePath)
	if err != nil {
		return nil, fmt.Errorf("failed to open image file %s: %v", imagePath, err)
	}
	defer file.Close()

	// Decode the image based on file extension
	var img image.Image
	if strings.HasSuffix(strings.ToLower(imagePath), ".png") {
		img, err = png.Decode(file)
	} else if strings.HasSuffix(strings.ToLower(imagePath), ".jpg") || strings.HasSuffix(strings.ToLower(imagePath), ".jpeg") {
		img, err = jpeg.Decode(file)
	} else {
		return nil, fmt.Errorf("unsupported image format: %s (only PNG and JPG/JPEG are supported)", imagePath)
	}

	if err != nil {
		return nil, fmt.Errorf("failed to decode image %s: %v", imagePath, err)
	}

	// Convert to RGBA format
	bounds := img.Bounds()
	rgba := image.NewRGBA(bounds)
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			rgba.Set(x, y, img.At(x, y))
		}
	}

	return rgba, nil
}

// createBackgroundTexture creates and uploads a texture once, returns texture ID
func createBackgroundTexture(img *image.RGBA) uint32 {
	if img == nil {
		return 0
	}

	// Generate texture
	var textureID uint32
	gl.GenTextures(1, &textureID)
	gl.BindTexture(gl.TEXTURE_2D, textureID)

	// Set texture parameters
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)

	// Get image dimensions
	imgBounds := img.Bounds()
	imgWidth := imgBounds.Dx()
	imgHeight := imgBounds.Dy()

	// Upload texture data
	gl.TexImage2D(gl.TEXTURE_2D, 0, gl.RGBA, int32(imgWidth), int32(imgHeight), 0, gl.RGBA, gl.UNSIGNED_BYTE, gl.Ptr(img.Pix))

	return textureID
}

// renderBackgroundImageSimple renders a background image with per-frame texture creation (stable but less efficient)
func renderBackgroundImageSimple(img *image.RGBA, windowWidth, windowHeight int) {
	if img == nil {
		return // No image to render
	}

	// Enable texturing
	gl.Enable(gl.TEXTURE_2D)

	// Generate texture for this frame
	var textureID uint32
	gl.GenTextures(1, &textureID)
	gl.BindTexture(gl.TEXTURE_2D, textureID)

	// Set texture parameters
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
	gl.TexParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)

	// Get image dimensions
	imgBounds := img.Bounds()
	imgWidth := imgBounds.Dx()
	imgHeight := imgBounds.Dy()

	// Upload texture data
	gl.TexImage2D(gl.TEXTURE_2D, 0, gl.RGBA, int32(imgWidth), int32(imgHeight), 0, gl.RGBA, gl.UNSIGNED_BYTE, gl.Ptr(img.Pix))

	// Calculate scaling to maintain aspect ratio and center the image
	scaleX := float64(windowWidth) / float64(imgWidth)
	scaleY := float64(windowHeight) / float64(imgHeight)
	
	// Use the smaller scale to maintain aspect ratio (fit image within window)
	scale := scaleX
	if scaleY < scaleX {
		scale = scaleY
	}

	// Calculate the scaled image dimensions
	scaledWidth := float64(imgWidth) * scale
	scaledHeight := float64(imgHeight) * scale

	// Calculate centering offsets
	offsetX := (float64(windowWidth) - scaledWidth) / 2.0
	offsetY := (float64(windowHeight) - scaledHeight) / 2.0

	// Convert to normalized device coordinates (-1 to 1)
	left := (offsetX / float64(windowWidth)) * 2.0 - 1.0
	right := ((offsetX + scaledWidth) / float64(windowWidth)) * 2.0 - 1.0
	bottom := 1.0 - ((offsetY + scaledHeight) / float64(windowHeight)) * 2.0
	top := 1.0 - (offsetY / float64(windowHeight)) * 2.0

	// Set color to white (no tinting)
	gl.Color4f(1.0, 1.0, 1.0, 1.0)

	// Render the background image
	gl.Begin(gl.QUADS)
	gl.TexCoord2f(0, 1)
	gl.Vertex2f(float32(left), float32(bottom)) // Bottom-left
	gl.TexCoord2f(1, 1)
	gl.Vertex2f(float32(right), float32(bottom)) // Bottom-right
	gl.TexCoord2f(1, 0)
	gl.Vertex2f(float32(right), float32(top)) // Top-right
	gl.TexCoord2f(0, 0)
	gl.Vertex2f(float32(left), float32(top)) // Top-left
	gl.End()

	// Clean up texture for this frame
	gl.Disable(gl.TEXTURE_2D)
	gl.DeleteTextures(1, &textureID)
}

// renderTextOptimized renders text with proper TrueType font support
func renderTextOptimized(text string, x, y, size float64, originalWidth, originalHeight, currentWidth, currentHeight int) {
	// Calculate scaling factors
	scaleX := float64(currentWidth) / float64(originalWidth)
	scaleY := float64(currentHeight) / float64(originalHeight)

	// Scale coordinates and size
	scaledX := x * scaleX
	scaledY := y * scaleY
	scaledSize := size * ((scaleX + scaleY) / 2.0) // Average scaling for size

	// Use the improved text rendering
	renderText(text, scaledX, scaledY, scaledSize, currentWidth, currentHeight)
}

// renderSimpleText renders text using proper character shapes for better readability
func renderSimpleText(text string, glX, glY, glSize float64) {
	// Set color to white
	gl.Color3f(1.0, 1.0, 1.0)

	// Character width and height based on size
	charWidth := glSize * 0.05
	charHeight := glSize * 0.08

	// Calculate starting position to center text
	totalWidth := float64(len(text)) * charWidth
	startX := glX - totalWidth/2.0

	// Render each character with proper shapes
	for i, char := range text {
		if char == ' ' {
			continue // Skip spaces
		}

		charX := startX + float64(i)*charWidth

		gl.Begin(gl.QUADS)

		// Render different characters with recognizable shapes
		switch char {
		case 'A':
			renderCharA(charX, glY, charWidth, charHeight)
		case 'B':
			renderCharB(charX, glY, charWidth, charHeight)
		case 'C':
			renderCharC(charX, glY, charWidth, charHeight)
		case 'D':
			renderCharD(charX, glY, charWidth, charHeight)
		case 'E':
			renderCharE(charX, glY, charWidth, charHeight)
		case 'F':
			renderCharF(charX, glY, charWidth, charHeight)
		case 'G':
			renderCharG(charX, glY, charWidth, charHeight)
		case 'H':
			renderCharH(charX, glY, charWidth, charHeight)
		case 'I':
			renderCharI(charX, glY, charWidth, charHeight)
		case 'J':
			renderCharJ(charX, glY, charWidth, charHeight)
		case 'K':
			renderCharK(charX, glY, charWidth, charHeight)
		case 'L':
			renderCharL(charX, glY, charWidth, charHeight)
		case 'M':
			renderCharM(charX, glY, charWidth, charHeight)
		case 'N':
			renderCharN(charX, glY, charWidth, charHeight)
		case 'O':
			renderCharO(charX, glY, charWidth, charHeight)
		case 'P':
			renderCharP(charX, glY, charWidth, charHeight)
		case 'Q':
			renderCharQ(charX, glY, charWidth, charHeight)
		case 'R':
			renderCharR(charX, glY, charWidth, charHeight)
		case 'S':
			renderCharS(charX, glY, charWidth, charHeight)
		case 'T':
			renderCharT(charX, glY, charWidth, charHeight)
		case 'U':
			renderCharU(charX, glY, charWidth, charHeight)
		case 'V':
			renderCharV(charX, glY, charWidth, charHeight)
		case 'W':
			renderCharW(charX, glY, charWidth, charHeight)
		case 'X':
			renderCharX(charX, glY, charWidth, charHeight)
		case 'Y':
			renderCharY(charX, glY, charWidth, charHeight)
		case 'Z':
			renderCharZ(charX, glY, charWidth, charHeight)
		case ',':
			renderCharComma(charX, glY, charWidth, charHeight)
		default:
			// Default character - render as a simple rectangle
			gl.Vertex2f(float32(charX), float32(glY-charHeight/2))
			gl.Vertex2f(float32(charX+charWidth*0.8), float32(glY-charHeight/2))
			gl.Vertex2f(float32(charX+charWidth*0.8), float32(glY+charHeight/2))
			gl.Vertex2f(float32(charX), float32(glY+charHeight/2))
		}

		gl.End()
	}
}

// Character rendering functions - optimized for performance
func renderCharA(x, y, width, height float64) {
	// Left vertical line
	gl.Vertex2f(float32(x), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.1), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.1), float32(y+height/2))
	gl.Vertex2f(float32(x), float32(y+height/2))
	// Right vertical line
	gl.Vertex2f(float32(x+width*0.7), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.8), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.8), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.7), float32(y+height/2))
	// Top horizontal line
	gl.Vertex2f(float32(x+width*0.1), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.7), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.7), float32(y+height*0.4))
	gl.Vertex2f(float32(x+width*0.1), float32(y+height*0.4))
	// Middle horizontal line
	gl.Vertex2f(float32(x+width*0.1), float32(y+height*0.05))
	gl.Vertex2f(float32(x+width*0.7), float32(y+height*0.05))
	gl.Vertex2f(float32(x+width*0.7), float32(y-height*0.05))
	gl.Vertex2f(float32(x+width*0.1), float32(y-height*0.05))
}

func renderCharB(x, y, width, height float64) {
	// Vertical line
	gl.Vertex2f(float32(x), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.1), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.1), float32(y+height/2))
	gl.Vertex2f(float32(x), float32(y+height/2))
	// Top horizontal
	gl.Vertex2f(float32(x+width*0.1), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.6), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.6), float32(y+height*0.4))
	gl.Vertex2f(float32(x+width*0.1), float32(y+height*0.4))
	// Middle horizontal
	gl.Vertex2f(float32(x+width*0.1), float32(y+height*0.05))
	gl.Vertex2f(float32(x+width*0.6), float32(y+height*0.05))
	gl.Vertex2f(float32(x+width*0.6), float32(y-height*0.05))
	gl.Vertex2f(float32(x+width*0.1), float32(y-height*0.05))
	// Bottom horizontal
	gl.Vertex2f(float32(x+width*0.1), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.6), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.6), float32(y-height*0.4))
	gl.Vertex2f(float32(x+width*0.1), float32(y-height*0.4))
}

func renderCharC(x, y, width, height float64) {
	// Vertical line
	gl.Vertex2f(float32(x), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.1), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.1), float32(y+height/2))
	gl.Vertex2f(float32(x), float32(y+height/2))
	// Top horizontal
	gl.Vertex2f(float32(x+width*0.1), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.7), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.7), float32(y+height*0.4))
	gl.Vertex2f(float32(x+width*0.1), float32(y+height*0.4))
	// Bottom horizontal
	gl.Vertex2f(float32(x+width*0.1), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.7), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.7), float32(y-height*0.4))
	gl.Vertex2f(float32(x+width*0.1), float32(y-height*0.4))
}

// Create distinct shapes for each letter
func renderCharD(x, y, width, height float64) {
	// Vertical line + curved right side (simplified as rectangle)
	gl.Vertex2f(float32(x), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.1), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.1), float32(y+height/2))
	gl.Vertex2f(float32(x), float32(y+height/2))
	// Right side
	gl.Vertex2f(float32(x+width*0.6), float32(y-height*0.3))
	gl.Vertex2f(float32(x+width*0.7), float32(y-height*0.3))
	gl.Vertex2f(float32(x+width*0.7), float32(y+height*0.3))
	gl.Vertex2f(float32(x+width*0.6), float32(y+height*0.3))
}

func renderCharE(x, y, width, height float64) {
	// Like C but with middle line
	renderCharC(x, y, width, height)
	// Middle horizontal
	gl.Vertex2f(float32(x+width*0.1), float32(y+height*0.05))
	gl.Vertex2f(float32(x+width*0.5), float32(y+height*0.05))
	gl.Vertex2f(float32(x+width*0.5), float32(y-height*0.05))
	gl.Vertex2f(float32(x+width*0.1), float32(y-height*0.05))
}

func renderCharF(x, y, width, height float64) {
	// Vertical line + top and middle horizontal
	gl.Vertex2f(float32(x), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.1), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.1), float32(y+height/2))
	gl.Vertex2f(float32(x), float32(y+height/2))
	// Top horizontal
	gl.Vertex2f(float32(x+width*0.1), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.6), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.6), float32(y+height*0.4))
	gl.Vertex2f(float32(x+width*0.1), float32(y+height*0.4))
	// Middle horizontal
	gl.Vertex2f(float32(x+width*0.1), float32(y+height*0.05))
	gl.Vertex2f(float32(x+width*0.5), float32(y+height*0.05))
	gl.Vertex2f(float32(x+width*0.5), float32(y-height*0.05))
	gl.Vertex2f(float32(x+width*0.1), float32(y-height*0.05))
}

// Simplified approach: use basic shapes for remaining letters
func renderCharG(x, y, width, height float64) { renderCharC(x, y, width, height) }
func renderCharH(x, y, width, height float64) { renderCharA(x, y, width, height) }
func renderCharI(x, y, width, height float64) {
	// Single vertical line
	gl.Vertex2f(float32(x+width*0.35), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.45), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.45), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.35), float32(y+height/2))
}
func renderCharJ(x, y, width, height float64) { renderCharI(x, y, width, height) }
func renderCharK(x, y, width, height float64) { renderCharA(x, y, width, height) }
func renderCharL(x, y, width, height float64) { renderCharF(x, y, width, height) }
func renderCharM(x, y, width, height float64) { renderCharA(x, y, width, height) }
func renderCharN(x, y, width, height float64) { renderCharA(x, y, width, height) }
func renderCharO(x, y, width, height float64) { renderCharC(x, y, width, height) }
func renderCharP(x, y, width, height float64) { renderCharB(x, y, width, height) }
func renderCharQ(x, y, width, height float64) { renderCharC(x, y, width, height) }
func renderCharR(x, y, width, height float64) { renderCharB(x, y, width, height) }
func renderCharS(x, y, width, height float64) { renderCharC(x, y, width, height) }
func renderCharT(x, y, width, height float64) {
	// Top horizontal + vertical line
	gl.Vertex2f(float32(x), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.8), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.8), float32(y+height*0.4))
	gl.Vertex2f(float32(x), float32(y+height*0.4))
	// Vertical line
	gl.Vertex2f(float32(x+width*0.35), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.45), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.45), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.35), float32(y+height/2))
}
func renderCharU(x, y, width, height float64) { renderCharC(x, y, width, height) }
func renderCharV(x, y, width, height float64) { renderCharA(x, y, width, height) }
func renderCharW(x, y, width, height float64) { renderCharA(x, y, width, height) }
func renderCharX(x, y, width, height float64) { renderCharA(x, y, width, height) }
func renderCharY(x, y, width, height float64) { renderCharA(x, y, width, height) }
func renderCharZ(x, y, width, height float64) {
	// Z shape with horizontals
	gl.Vertex2f(float32(x), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.7), float32(y+height/2))
	gl.Vertex2f(float32(x+width*0.7), float32(y+height*0.4))
	gl.Vertex2f(float32(x), float32(y+height*0.4))
	// Bottom horizontal
	gl.Vertex2f(float32(x), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.7), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.7), float32(y-height*0.4))
	gl.Vertex2f(float32(x), float32(y-height*0.4))
}
func renderCharComma(x, y, width, height float64) {
	// Small rectangle at bottom
	gl.Vertex2f(float32(x+width*0.3), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.5), float32(y-height/2))
	gl.Vertex2f(float32(x+width*0.5), float32(y-height*0.3))
	gl.Vertex2f(float32(x+width*0.3), float32(y-height*0.3))
}

// executeWindowDefinition handles window definition with block parsing
func executeWindowDefinition(lines []string, startIdx int) (int, error) {
	line := strings.TrimSpace(lines[startIdx])

	// Parse: window name {
	parts := strings.Fields(line)
	if len(parts) < 2 {
		return startIdx, fmt.Errorf("invalid window definition syntax")
	}

	windowName := parts[1]

	// Parse the block and extract parameters
	blockLines, nextI, err := parseBlock(lines, startIdx+1)
	if err != nil {
		return startIdx, fmt.Errorf("error parsing window block: %s", err)
	}

	// Initialize window definition with default values
	windowDef := make(map[string]string)
	windowDef["name"] = windowName // Default name is the window identifier

	// Parse parameters inside the block
	var popElements []PopElement

	for i := 0; i < len(blockLines); i++ {
		blockLine := strings.TrimSpace(blockLines[i])

		// Skip empty lines and comments
		if blockLine == "" || strings.HasPrefix(blockLine, "//") || strings.HasPrefix(blockLine, "#") {
			continue
		}

		// Handle pop blocks
		if strings.HasPrefix(blockLine, "pop ") && strings.Contains(blockLine, "{") {
			popElement, newI, err := parsePopElement(blockLines, i)
			if err != nil {
				return startIdx, fmt.Errorf("error parsing pop element: %s", err)
			}
			popElements = append(popElements, popElement)
			i = newI - 1 // Adjust for loop increment
			continue
		}

		// Look for parameter definitions like "name: value"
		if strings.Contains(blockLine, ":") {
			colonIdx := strings.Index(blockLine, ":")
			paramName := strings.TrimSpace(blockLine[:colonIdx])
			paramValue := strings.TrimSpace(blockLine[colonIdx+1:])

			// Remove // comments from the end of the line
			if commentIdx := strings.Index(paramValue, "//"); commentIdx != -1 {
				paramValue = strings.TrimSpace(paramValue[:commentIdx])
			}

			// Store the parameter
			windowDef[paramName] = paramValue
		}
	}

	// Store pop elements for this window
	if len(popElements) > 0 {
		windowPopElements[windowName] = popElements
		fmt.Printf("✓ Parsed %d pop element(s) for window '%s'\n", len(popElements), windowName)
		for _, pop := range popElements {
			fmt.Printf("  - Pop '%s': text='%s', size=%.1f, pos=(%.1f,%.1f)\n", pop.Name, pop.Text, pop.Size, pop.X, pop.Y)
		}
	}

	// Store the window definition
	windowDefinitions[windowName] = windowDef

	return nextI, nil
}

// parsePopElement parses a pop element block and returns the PopElement and new index
func parsePopElement(blockLines []string, startIdx int) (PopElement, int, error) {
	line := strings.TrimSpace(blockLines[startIdx])

	// Parse: pop name {
	parts := strings.Fields(line)
	if len(parts) < 2 {
		return PopElement{}, startIdx, fmt.Errorf("invalid pop definition syntax")
	}

	popName := parts[1]
	popElement := PopElement{
		Name: popName,
		Size: 24.0, // Default size
		X:    0.0,  // Default position
		Y:    0.0,
	}

	// Find the opening brace and parse until closing brace
	braceCount := 1
	i := startIdx + 1

	for i < len(blockLines) && braceCount > 0 {
		popLine := strings.TrimSpace(blockLines[i])

		// Skip empty lines and comments
		if popLine == "" || strings.HasPrefix(popLine, "//") || strings.HasPrefix(popLine, "#") {
			i++
			continue
		}

		// Count braces
		openBraces := strings.Count(popLine, "{")
		closeBraces := strings.Count(popLine, "}")
		braceCount += openBraces - closeBraces

		if braceCount == 0 {
			break
		}

		// Parse text() function
		if strings.HasPrefix(popLine, "text(") && strings.Contains(popLine, ")") {
			// Find the closing parenthesis, accounting for comments
			closeParenIdx := strings.Index(popLine, ")")
			if closeParenIdx > 5 {
				textContent := popLine[5:closeParenIdx] // Remove text( and )
				// Remove quotes if present
				if len(textContent) >= 2 && textContent[0] == '"' && textContent[len(textContent)-1] == '"' {
					textContent = textContent[1 : len(textContent)-1]
				}
				popElement.Text = textContent
			}
		}

		// Parse size parameter
		if strings.HasPrefix(popLine, "size") && strings.Contains(popLine, "=") {
			parts := strings.Split(popLine, "=")
			if len(parts) == 2 {
				sizeStr := strings.TrimSpace(parts[1])
				// Remove comments
				if commentIdx := strings.Index(sizeStr, "//"); commentIdx != -1 {
					sizeStr = strings.TrimSpace(sizeStr[:commentIdx])
				}
				if size, err := strconv.ParseFloat(sizeStr, 64); err == nil {
					popElement.Size = size
				}
			}
		}

		// Parse middle parameter
		if strings.HasPrefix(popLine, "middle") && strings.Contains(popLine, "=") {
			parts := strings.Split(popLine, "=")
			if len(parts) == 2 {
				coordStr := strings.TrimSpace(parts[1])
				// Remove comments
				if commentIdx := strings.Index(coordStr, "//"); commentIdx != -1 {
					coordStr = strings.TrimSpace(coordStr[:commentIdx])
				}

				// Parse x(value), y(value) format
				xMatch := regexp.MustCompile(`x\(([^)]+)\)`).FindStringSubmatch(coordStr)
				yMatch := regexp.MustCompile(`y\(([^)]+)\)`).FindStringSubmatch(coordStr)

				if len(xMatch) > 1 {
					if x, err := strconv.ParseFloat(xMatch[1], 64); err == nil {
						popElement.X = x
					}
				}
				if len(yMatch) > 1 {
					if y, err := strconv.ParseFloat(yMatch[1], 64); err == nil {
						popElement.Y = y
					}
				}
			}
		}

		i++
	}

	return popElement, i + 1, nil
}

func main() {
	// Set up cleanup for GLFW when program exits
	defer func() {
		if glfwInitialized {
			glfw.Terminate()
		}
	}()

	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: blink <file>.blink")
		os.Exit(1)
	}
	filename := os.Args[1]
	source, err := os.ReadFile(filename)
	if err != nil {
		fmt.Fprintln(os.Stderr, "error reading file:", err)
		os.Exit(1)
	}
	vars := make(map[string]interface{})
	stopped := false // Track if execution is stopped

	lines := strings.Split(string(source), "\n")

	for i := 0; i < len(lines); i++ {
		line := strings.TrimSpace(lines[i])
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") || line == "}" || line == "} else {" || strings.Contains(line, "} else {") {
			continue
		}

		// Handle unstop command first (even when stopped)
		if line == "unstop" {
			if stopped {
				fmt.Println("un-stopped")
				stopped = false
			}
			continue
		}

		// If execution is stopped, skip all lines except unstop
		if stopped {
			continue
		}

		// Handle stop command
		if line == "stop" {
			fmt.Println("stopped")
			stopped = true
			continue
		}

		// Handle if statements (NO else support)
		if strings.HasPrefix(line, "if ") {
			// Parse and execute simple if statement
			newI, err := executeSimpleIf(lines, i, vars)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
			}
			i = newI - 1 // Adjust for loop increment
			continue
		}

		// Handle loop statements
		if strings.HasPrefix(line, "loop ") {
			// Parse and execute loop statement
			newI, err := executeLoop(lines, i, vars)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
			}
			i = newI - 1 // Adjust for loop increment
			continue
		}

		// Handle ask statements
		if strings.HasPrefix(line, "ask(") {
			// Parse and execute ask statement
			newI, err := executeAsk(lines, i, vars)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
			}
			i = newI - 1 // Adjust for loop increment
			continue
		}

		// Handle random statements
		if strings.HasPrefix(line, "random(") {
			// Parse and execute random statement
			newI, err := executeRandom(lines, i, vars)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
			}
			i = newI - 1 // Adjust for loop increment
			continue
		}

		// Handle window statements
		if strings.HasPrefix(line, "window ") {
			// Handle window definition: window name {
			if strings.Contains(line, "{") {
				// Parse and execute window definition
				newI, err := executeWindowDefinition(lines, i)
				if err != nil {
					fmt.Fprintln(os.Stderr, err)
				}
				i = newI - 1 // Adjust for loop increment
				continue
			}
			// Handle window open/close commands
			if strings.Contains(line, "open ") {
				if err := executeWindowOpen(line); err != nil {
					fmt.Fprintln(os.Stderr, err)
				}
				continue
			}
			if strings.Contains(line, "close ") {
				if err := executeWindowClose(line); err != nil {
					fmt.Fprintln(os.Stderr, err)
				}
				continue
			}
		}

		// Execute regular line
		if err := executeLine(line, vars, i+1); err != nil {
			fmt.Fprintln(os.Stderr, err)
		}
	}
}

// ConditionalStatement represents an if/else-if/else statement
type ConditionalStatement struct {
	Condition string
	Block     []string
	Type      string // "if", "else-if", "else"
}

// executeSimpleIf executes an if statement with optional else support and returns the new line index
func executeSimpleIf(lines []string, startIdx int, vars map[string]interface{}) (int, error) {
	i := startIdx

	// Parse if statement
	line := strings.TrimSpace(lines[i])
	if !strings.HasPrefix(line, "if ") {
		return i, fmt.Errorf("expected if statement")
	}

	// Parse if condition
	ifPart := strings.TrimSpace(line[3:])
	if !strings.HasSuffix(ifPart, "{") {
		return i, fmt.Errorf("error (line %d): if statement must end with {", i+1)
	}
	condition := strings.TrimSpace(ifPart[:len(ifPart)-1])

	// Evaluate if condition
	result, err := evaluateCondition(condition, vars)
	if err != nil {
		return i, fmt.Errorf("error (line %d) evaluating condition '%s': %s", i+1, condition, err)
	}

	// Parse if block
	ifBlock, nextI, err := parseBlock(lines, i+1)
	if err != nil {
		return i, fmt.Errorf("error (line %d): %s", i+1, err)
	}

	// Check for else block - check the line where the block ended (nextI-1)
	var elseBlock []string
	finalI := nextI
	elseLineIdx := nextI - 1
	if elseLineIdx >= 0 && elseLineIdx < len(lines) {
		elseLine := strings.TrimSpace(lines[elseLineIdx])
		// Handle "} else {" on same line
		if strings.Contains(elseLine, "else {") {
			// Parse else block using specialized function
			elseBlock, finalI, err = parseElseBlock(lines, elseLineIdx)
			if err != nil {
				return i, fmt.Errorf("error (line %d): %s", elseLineIdx+1, err)
			}
		}
	}

	// Execute appropriate block based on condition
	if result {
		// Execute if block
		if err := executeBlock(ifBlock, vars); err != nil {
			return i, err
		}
	} else if len(elseBlock) > 0 {
		// Execute else block
		if err := executeBlock(elseBlock, vars); err != nil {
			return i, err
		}
	}

	return finalI, nil
}

// evaluateCondition evaluates a boolean condition
func evaluateCondition(condition string, vars map[string]interface{}) (bool, error) {
	condition = strings.TrimSpace(condition)

	// Try comparison first
	result, err := evaluateComparison(condition, vars)
	if err == nil {
		return result, nil
	}

	// Try expression evaluation
	condResult, err := evaluateExpression(condition, vars)
	if err != nil {
		return false, err
	}

	if boolVal, ok := condResult.(bool); ok {
		return boolVal, nil
	}

	return false, fmt.Errorf("condition must be boolean")
}

// parseBlock parses a block of code between braces
func parseBlock(lines []string, startIdx int) ([]string, int, error) {
	var block []string
	braceCount := 1
	i := startIdx

	for i < len(lines) && braceCount > 0 {
		line := strings.TrimSpace(lines[i])

		// Skip empty lines and comments
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") {
			i++
			continue
		}

		// Count braces in the line
		openBraces := strings.Count(line, "{")
		closeBraces := strings.Count(line, "}")

		// Add the line to the block before updating brace count
		// Include all lines, including closing braces (needed for nested blocks)
		block = append(block, lines[i])

		// Update brace count
		braceCount += openBraces - closeBraces

		// If we've closed all braces, we're done
		if braceCount == 0 {
			return block, i + 1, nil
		}

		i++
	}

	if braceCount > 0 {
		return nil, i, fmt.Errorf("unclosed block")
	}

	return block, i, nil
}

// parseElseBlock parses an else block starting from the "} else {" line
func parseElseBlock(lines []string, elseLineIdx int) ([]string, int, error) {
	var block []string
	braceCount := 1
	i := elseLineIdx + 1 // Start from the line after "} else {"

	for i < len(lines) && braceCount > 0 {
		line := strings.TrimSpace(lines[i])

		// Count braces more carefully - count each brace character
		for _, char := range line {
			if char == '{' {
				braceCount++
			} else if char == '}' {
				braceCount--
			}
		}

		// Check if we've reached the end of the block
		if braceCount == 0 {
			return block, i + 1, nil
		}

		if braceCount > 0 && line != "}" && !strings.Contains(line, "}") {
			block = append(block, lines[i])
		}

		i++
	}

	if braceCount > 0 {
		return nil, i, fmt.Errorf("unclosed else block")
	}

	return block, i, nil
}

// parseSingleBlock parses a single block between { and } and returns the block and new index
func parseSingleBlock(lines []string, startIdx int) ([]string, int) {
	var block []string
	braceCount := 1
	i := startIdx

	for i < len(lines) && braceCount > 0 {
		line := strings.TrimSpace(lines[i])

		if line == "{" {
			braceCount++
		} else if line == "}" {
			braceCount--
		}

		if braceCount > 0 {
			block = append(block, lines[i])
		}
		i++
	}

	return block, i
}
