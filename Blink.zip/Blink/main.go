package main

import (
	"fmt"
	"math/rand"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// evaluateComparison evaluates comparison expressions (>, <, ==, etc.)
func evaluateComparison(expr string, vars map[string]interface{}) (bool, error) {
	expr = strings.TrimSpace(expr)

	// Check for comparison operators
	compOps := []string{"==", "!=", ">=", "<=", ">", "<"}

	for _, op := range compOps {
		idx := strings.Index(expr, op)
		if idx > 0 && idx < len(expr)-len(op) {
			left := strings.TrimSpace(expr[:idx])
			right := strings.TrimSpace(expr[idx+len(op):])

			// Try to get values directly (avoid recursion)
			var leftResult, rightResult interface{}
			var leftErr, rightErr error

			// Get left value
			if val, ok := vars[left]; ok {
				leftResult = val
			} else if left == "true" || left == "false" {
				leftResult = left == "true"
			} else if len(left) >= 2 && left[0] == '"' && left[len(left)-1] == '"' {
				leftResult = left[1 : len(left)-1]
			} else if val, err := strconv.ParseFloat(left, 64); err == nil {
				leftResult = val
			} else {
				leftErr = fmt.Errorf("undefined variable: %s", left)
			}

			// Get right value
			if val, ok := vars[right]; ok {
				rightResult = val
			} else if right == "true" || right == "false" {
				rightResult = right == "true"
			} else if len(right) >= 2 && right[0] == '"' && right[len(right)-1] == '"' {
				rightResult = right[1 : len(right)-1]
			} else if val, err := strconv.ParseFloat(right, 64); err == nil {
				rightResult = val
			} else {
				rightErr = fmt.Errorf("undefined variable: %s", right)
			}

			// If both succeeded, compare the results
			if leftErr == nil && rightErr == nil {
				// Handle different type combinations
				switch leftVal := leftResult.(type) {
				case float64:
					if rightVal, ok := rightResult.(float64); ok {
						switch op {
						case "==":
							return leftVal == rightVal, nil
						case "!=":
							return leftVal != rightVal, nil
						case ">":
							return leftVal > rightVal, nil
						case "<":
							return leftVal < rightVal, nil
						case ">=":
							return leftVal >= rightVal, nil
						case "<=":
							return leftVal <= rightVal, nil
						}
					}
				case string:
					if rightVal, ok := rightResult.(string); ok {
						switch op {
						case "==":
							return leftVal == rightVal, nil
						case "!=":
							return leftVal != rightVal, nil
						}
					}
				case bool:
					if rightVal, ok := rightResult.(bool); ok {
						switch op {
						case "==":
							return leftVal == rightVal, nil
						case "!=":
							return leftVal != rightVal, nil
						}
					}
				}
			}

			// Fallback to numeric comparison
			leftVal, err := getNumericValue(left, vars)
			if err != nil {
				return false, err
			}

			rightVal, err := getNumericValue(right, vars)
			if err != nil {
				return false, err
			}

			switch op {
			case "==":
				return leftVal == rightVal, nil
			case "!=":
				return leftVal != rightVal, nil
			case ">":
				return leftVal > rightVal, nil
			case "<":
				return leftVal < rightVal, nil
			case ">=":
				return leftVal >= rightVal, nil
			case "<=":
				return leftVal <= rightVal, nil
			}
		}
	}

	return false, fmt.Errorf("no comparison operator found in: %s", expr)
}

// evaluateExpression parses and evaluates arithmetic expressions
func evaluateExpression(expr string, vars map[string]interface{}) (interface{}, error) {
	expr = strings.TrimSpace(expr)

	// Handle parentheses - but only if they wrap the entire expression
	if strings.HasPrefix(expr, "(") && strings.HasSuffix(expr, ")") {
		// Check if these parentheses actually wrap the whole expression
		parenCount := 0
		for i, char := range expr {
			if char == '(' {
				parenCount++
			} else if char == ')' {
				parenCount--
				if parenCount == 0 && i < len(expr)-1 {
					// Parentheses closed before the end, so they don't wrap everything
					break
				}
			}
		}
		if parenCount == 0 {
			inner := expr[1 : len(expr)-1]
			return evaluateExpression(inner, vars)
		}
	}

	// Check for comparison operators first (return boolean)
	// But only if they're not inside parentheses and not part of a string concatenation
	compOps := []string{"==", "!=", ">=", "<=", ">", "<"}
	for _, op := range compOps {
		parenCount := 0
		inString := false
		for i := 0; i < len(expr)-len(op)+1; i++ {
			if expr[i] == '"' {
				inString = !inString
			} else if !inString {
				if expr[i] == '(' {
					parenCount++
				} else if expr[i] == ')' {
					parenCount--
				} else if parenCount == 0 && strings.HasPrefix(expr[i:], op) {
					// Found a comparison operator at the top level
					return evaluateComparison(expr, vars)
				}
			}
		}
	}

	// Check for + operator first (could be string concatenation or addition)
	// Find the rightmost + that's not inside parentheses
	parenCount := 0
	plusIdx := -1
	for i := len(expr) - 1; i >= 0; i-- {
		if expr[i] == ')' {
			parenCount++
		} else if expr[i] == '(' {
			parenCount--
		} else if expr[i] == '+' && parenCount == 0 {
			plusIdx = i
			break
		}
	}

	if plusIdx > 0 && plusIdx < len(expr)-1 {
		left := strings.TrimSpace(expr[:plusIdx])
		right := strings.TrimSpace(expr[plusIdx+1:])

		// Recursively evaluate both sides
		leftResult, leftErr := evaluateExpression(left, vars)
		rightResult, rightErr := evaluateExpression(right, vars)

		// If both are numbers, do arithmetic addition
		if leftNum, leftOk := leftResult.(float64); leftOk {
			if rightNum, rightOk := rightResult.(float64); rightOk {
				return leftNum + rightNum, nil
			}
		}

		// Otherwise, do string concatenation
		leftStr := toString(leftResult)
		rightStr := toString(rightResult)

		// Handle errors by falling back to string values
		if leftErr != nil {
			leftStr = getStringValue(left, vars)
		}
		if rightErr != nil {
			rightStr = getStringValue(right, vars)
		}

		return leftStr + rightStr, nil
	}

	// Check for other arithmetic operators
	operators := []string{"*", "/", "-"}

	for _, op := range operators {
		// Find the rightmost occurrence of the operator
		idx := strings.LastIndex(expr, op)
		if idx > 0 && idx < len(expr)-1 {
			left := strings.TrimSpace(expr[:idx])
			right := strings.TrimSpace(expr[idx+1:])

			leftVal, err := getNumericValue(left, vars)
			if err != nil {
				return 0, err
			}

			rightVal, err := getNumericValue(right, vars)
			if err != nil {
				return 0, err
			}

			switch op {
			case "-":
				return leftVal - rightVal, nil
			case "*":
				return leftVal * rightVal, nil
			case "/":
				if rightVal == 0 {
					return 0, fmt.Errorf("division by zero")
				}
				return leftVal / rightVal, nil
			}
		}
	}

	// No operators found, treat as single value
	// Try to get from variables first (could be any type)
	if val, ok := vars[expr]; ok {
		return val, nil
	}

	// Try as number
	if val, err := getNumericValue(expr, vars); err == nil {
		return val, nil
	}
	// Try as string literal or variable
	return getStringValue(expr, vars), nil
}

// toString converts any value to string
func toString(val interface{}) string {
	switch v := val.(type) {
	case string:
		return v
	case float64:
		return fmt.Sprintf("%g", v)
	case bool:
		if v {
			return "true"
		}
		return "false"
	default:
		return fmt.Sprintf("%v", v)
	}
}

// getStringValue gets the string representation of a value
func getStringValue(s string, vars map[string]interface{}) string {
	s = strings.TrimSpace(s)

	// First, try to get from variables (prioritize variables over literals)
	if val, ok := vars[s]; ok {
		return toString(val)
	}

	// String literal
	if len(s) >= 2 && s[0] == '"' && s[len(s)-1] == '"' {
		return s[1 : len(s)-1]
	}

	// Return as-is if not found
	return s
}

// getNumericValue gets the float64 value of a variable or number
func getNumericValue(s string, vars map[string]interface{}) (float64, error) {
	s = strings.TrimSpace(s)

	// First, try to get from variables (prioritize variables over literals)
	if val, ok := vars[s]; ok {
		if floatVal, ok := val.(float64); ok {
			return floatVal, nil
		}
		return 0, fmt.Errorf("variable %s is not a number", s)
	}

	// Skip string literals - they shouldn't be parsed as numbers
	if len(s) >= 2 && s[0] == '"' {
		return 0, fmt.Errorf("cannot convert string literal to number: %s", s)
	}

	// Skip boolean literals - they shouldn't be parsed as numbers
	if s == "true" || s == "false" {
		return 0, fmt.Errorf("cannot convert boolean literal to number: %s", s)
	}

	// If not found as variable, try to parse as float literal
	if val, err := strconv.ParseFloat(s, 64); err == nil {
		return val, nil
	}

	return 0, fmt.Errorf("undefined variable or invalid number: %s", s)
}

// executeBlock executes a block of statements
func executeBlock(lines []string, vars map[string]interface{}) error {
	for i := 0; i < len(lines); i++ {
		line := strings.TrimSpace(lines[i])
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") || line == "}" || line == "} else {" || strings.Contains(line, "} else {") {
			continue
		}

		// Handle nested if statements (NO else support)
		if strings.HasPrefix(line, "if ") {
			// Parse and execute simple if statement
			newI, err := executeSimpleIf(lines, i, vars)
			if err != nil {
				return err
			}
			i = newI
			continue
		}

		// Handle nested loop statements
		if strings.HasPrefix(line, "loop ") {
			// For nested loops, we need to handle them differently
			// Parse the loop count
			loopPart := strings.TrimSpace(line[5:]) // Skip "loop "
			if !strings.HasSuffix(loopPart, "{") {
				return fmt.Errorf("loop statement must end with {")
			}
			
			countStr := strings.TrimSpace(loopPart[:len(loopPart)-1])
			
			// Evaluate the loop count
			var loopCount int
			if val, exists := vars[countStr]; exists {
				if floatVal, ok := val.(float64); ok {
					loopCount = int(floatVal)
				} else {
					return fmt.Errorf("loop count variable '%s' is not a number", countStr)
				}
			} else {
				if count, err := strconv.Atoi(countStr); err == nil {
					loopCount = count
				} else {
					return fmt.Errorf("invalid loop count: %s", countStr)
				}
			}
			
			// Parse the nested loop block
			nestedBlock, newI, err := parseBlock(lines, i+1)
			if err != nil {
				return fmt.Errorf("error parsing nested loop: %s", err)
			}
			
			// Execute the nested loop
			for iteration := 0; iteration < loopCount; iteration++ {
				// Set the loop variable 'i' to the current iteration number
				vars["i"] = float64(iteration)
				
				if err := executeBlock(nestedBlock, vars); err != nil {
					return fmt.Errorf("error in nested loop iteration %d: %s", iteration+1, err)
				}
			}
			
			i = newI
			continue
		}

		// Handle nested ask statements
		if strings.HasPrefix(line, "ask(") {
			// Parse and execute nested ask statement
			newI, err := executeAsk(lines, i, vars)
			if err != nil {
				return fmt.Errorf("error in nested ask: %s", err)
			}
			i = newI
			continue
		}

		// Handle nested random statements
		if strings.HasPrefix(line, "random(") {
			// Parse and execute nested random statement
			newI, err := executeRandom(lines, i, vars)
			if err != nil {
				return fmt.Errorf("error in nested random: %s", err)
			}
			i = newI
			continue
		}

		if err := executeLine(line, vars, i+1); err != nil {
			return err
		}
	}
	return nil
}

// executeLine executes a single line of code
func executeLine(line string, vars map[string]interface{}, lineNo int) error {
	line = strings.TrimSpace(line)

	// Check for remove command first (before assignment parsing)
	if strings.HasPrefix(line, "remove = ") {
		return executeRemoveCommand(line, vars, lineNo)
	}

	// assignment: name = value (but not comparison ==)
	// Find the first = that's not part of a comparison operator
	assignIdx := -1
	for i := 0; i < len(line); i++ {
		if line[i] == '=' {
			// Check if it's part of ==, !=, >=, <=
			if (i > 0 && (line[i-1] == '!' || line[i-1] == '>' || line[i-1] == '<')) ||
				(i < len(line)-1 && line[i+1] == '=') {
				continue // Skip comparison operators
			}
			assignIdx = i
			break
		}
	}

	if assignIdx > 0 {
		name := strings.TrimSpace(line[:assignIdx])
		value := strings.TrimSpace(line[assignIdx+1:])

		// Check if variable already exists (overwrite protection)
		if _, exists := vars[name]; exists {
			return fmt.Errorf("error (line %d): You cannot set new variable \"%s\" because it already exists but here is what you can do if you want to remove the old variable and make new one with same name:\n\nremove = %s\n// and now you can set the variable again:\n%s = <new_value>", lineNo, name, name, name)
		}

		// string literal
		if len(value) >= 2 && value[0] == '"' && value[len(value)-1] == '"' {
			unquoted := value[1 : len(value)-1]
			vars[name] = unquoted
			return nil
		}
		// boolean literal
		if value == "true" || value == "false" {
			vars[name] = value == "true"
			return nil
		}
		// number (float) - only if it's not being assigned to a variable
		if f, err := strconv.ParseFloat(value, 64); err == nil {
			vars[name] = f
			return nil
		}
		// expression
		if result, err := evaluateExpression(value, vars); err == nil {
			vars[name] = result
			return nil
		}
		// fallback: store as raw string (without quotes)
		vars[name] = value
		return nil
	}

	// say(...) -- allow spaces like say(  "x"  )
	re := regexp.MustCompile(`^say\s*\(\s*(.*)\s*\)\s*$`)
	m := re.FindStringSubmatch(line)
	if len(m) == 2 {
		arg := m[1]

		// Always try to evaluate as expression first (handles both arithmetic and string concatenation)
		if strings.ContainsAny(arg, "+-*/") {
			result, err := evaluateExpression(arg, vars)
			if err != nil {
				// If expression evaluation fails and it's a simple string literal, treat as string
				if len(arg) >= 2 && arg[0] == '"' && arg[len(arg)-1] == '"' {
					fmt.Println(arg[1 : len(arg)-1])
					return nil
				}
				return fmt.Errorf("error (line %d): %s", lineNo, err)
			}
			fmt.Println(result)
			return nil
		}

		// string literal
		if len(arg) >= 2 && arg[0] == '"' && arg[len(arg)-1] == '"' {
			fmt.Println(arg[1 : len(arg)-1])
			return nil
		}

		// identifier: must exist
		if val, ok := vars[arg]; ok {
			fmt.Println(val)
		} else {
			return fmt.Errorf("error (line %d): undefined variable %s", lineNo, arg)
		}
		return nil
	}

	// wait command: wait <duration>
	if strings.HasPrefix(line, "wait ") {
		durationStr := strings.TrimSpace(line[5:])
		if duration, err := strconv.ParseFloat(durationStr, 64); err == nil {
			time.Sleep(time.Duration(duration * float64(time.Second)))
			return nil
		} else {
			return fmt.Errorf("error (line %d): invalid wait duration: %s", lineNo, durationStr)
		}
	}

	return fmt.Errorf("error (line %d): unknown statement: %s", lineNo, line)
}

// executeRemoveCommand handles the remove command for variables and future extensibility
func executeRemoveCommand(line string, vars map[string]interface{}, lineNo int) error {
	// Extract the items to remove after "remove = "
	itemsStr := strings.TrimSpace(line[9:]) // Skip "remove = "
	
	if itemsStr == "" {
		return fmt.Errorf("error (line %d): remove command requires at least one item to remove", lineNo)
	}
	
	// Split by comma and process each item
	items := strings.Split(itemsStr, ",")
	removedItems := []string{}
	notFoundItems := []string{}
	
	for _, item := range items {
		item = strings.TrimSpace(item)
		if item == "" {
			continue
		}
		
		// For now, we only support removing variables
		// In the future, this can be extended to support other types like windows
		if err := removeVariable(item, vars); err != nil {
			notFoundItems = append(notFoundItems, item)
		} else {
			removedItems = append(removedItems, item)
		}
	}
	
	// Provide feedback about what was removed
	if len(removedItems) > 0 {
		fmt.Printf("Removed variables: %s\n", strings.Join(removedItems, ", "))
	}
	
	if len(notFoundItems) > 0 {
		return fmt.Errorf("error (line %d): cannot remove non-existent variables: %s", lineNo, strings.Join(notFoundItems, ", "))
	}
	
	return nil
}

// removeVariable removes a variable from the variables map
// This function is designed to be extensible for future removal types
func removeVariable(name string, vars map[string]interface{}) error {
	if _, exists := vars[name]; !exists {
		return fmt.Errorf("variable %s does not exist", name)
	}
	
	delete(vars, name)
	return nil
}

// executeLoop executes a loop statement with specified iterations
func executeLoop(lines []string, startIdx int, vars map[string]interface{}) (int, error) {
	i := startIdx
	
	// Parse loop statement
	line := strings.TrimSpace(lines[i])
	if !strings.HasPrefix(line, "loop ") {
		return i, fmt.Errorf("expected loop statement")
	}
	
	// Parse loop count and opening brace
	loopPart := strings.TrimSpace(line[5:]) // Skip "loop "
	if !strings.HasSuffix(loopPart, "{") {
		return i, fmt.Errorf("error (line %d): loop statement must end with {", i+1)
	}
	
	// Extract the loop count
	countStr := strings.TrimSpace(loopPart[:len(loopPart)-1])
	
	// Evaluate the loop count (could be a variable or number)
	var loopCount int
	if val, exists := vars[countStr]; exists {
		// Try to convert variable to number
		if floatVal, ok := val.(float64); ok {
			loopCount = int(floatVal)
		} else {
			return i, fmt.Errorf("error (line %d): loop count variable '%s' is not a number", i+1, countStr)
		}
	} else {
		// Try to parse as number literal
		if count, err := strconv.Atoi(countStr); err == nil {
			loopCount = count
		} else {
			return i, fmt.Errorf("error (line %d): invalid loop count: %s", i+1, countStr)
		}
	}
	
	if loopCount < 0 {
		return i, fmt.Errorf("error (line %d): loop count cannot be negative: %d", i+1, loopCount)
	}
	
	// Parse loop block
	loopBlock, nextI, err := parseBlock(lines, i+1)
	if err != nil {
		return i, fmt.Errorf("error (line %d): %s", i+1, err)
	}
	
	// Execute the loop block the specified number of times
	for iteration := 0; iteration < loopCount; iteration++ {
		// Set the loop variable 'i' to the current iteration number
		vars["i"] = float64(iteration)
		
		// Create a copy of the loop block for each iteration to avoid line number conflicts
		blockCopy := make([]string, len(loopBlock))
		copy(blockCopy, loopBlock)
		
		if err := executeBlock(blockCopy, vars); err != nil {
			return i, fmt.Errorf("error in loop iteration %d: %s", iteration+1, err)
		}
	}
	
	return nextI, nil
}

// executeAsk executes an ask statement with user input
func executeAsk(lines []string, startIdx int, vars map[string]interface{}) (int, error) {
	i := startIdx
	
	// Parse ask statement
	line := strings.TrimSpace(lines[i])
	if !strings.HasPrefix(line, "ask(") {
		return i, fmt.Errorf("expected ask statement")
	}
	
	// Extract the question from ask("question"){
	questionStart := strings.Index(line, "ask(") + 4
	questionEnd := strings.Index(line[questionStart:], ")") + questionStart
	if questionEnd <= questionStart {
		return i, fmt.Errorf("error (line %d): malformed ask statement", i+1)
	}
	
	question := line[questionStart:questionEnd]
	
	// Remove quotes from question if present
	if len(question) >= 2 && question[0] == '"' && question[len(question)-1] == '"' {
		question = question[1 : len(question)-1]
	}
	
	// Check for opening brace
	if !strings.Contains(line, "{") {
		return i, fmt.Errorf("error (line %d): ask statement must end with {", i+1)
	}
	
	// Display the question and get user input
	fmt.Println(question)
	fmt.Print("> ")
	var userInput string
	fmt.Scanln(&userInput)
	
	// Set the answer variable
	vars["answer"] = userInput
	
	// Parse ask block
	askBlock, nextI, err := parseBlock(lines, i+1)
	if err != nil {
		return i, fmt.Errorf("error (line %d): %s", i+1, err)
	}
	
	// Execute the ask block
	if err := executeBlock(askBlock, vars); err != nil {
		return i, fmt.Errorf("error in ask block: %s", err)
	}
	
	return nextI, nil
}

// executeRandom executes a random statement with random selection
func executeRandom(lines []string, startIdx int, vars map[string]interface{}) (int, error) {
	i := startIdx
	
	// Parse random statement
	line := strings.TrimSpace(lines[i])
	if !strings.HasPrefix(line, "random(") {
		return i, fmt.Errorf("expected random statement")
	}
	
	// Extract the options from random(option1, option2, ...){
	optionsStart := strings.Index(line, "random(") + 7
	optionsEnd := strings.Index(line[optionsStart:], ")") + optionsStart
	if optionsEnd <= optionsStart {
		return i, fmt.Errorf("error (line %d): malformed random statement", i+1)
	}
	
	optionsStr := line[optionsStart:optionsEnd]
	
	// Parse options by splitting on commas
	var options []string
	if strings.TrimSpace(optionsStr) != "" {
		rawOptions := strings.Split(optionsStr, ",")
		for _, option := range rawOptions {
			trimmed := strings.TrimSpace(option)
			if trimmed != "" {
				options = append(options, trimmed)
			}
		}
	}
	
	if len(options) == 0 {
		return i, fmt.Errorf("error (line %d): random statement must have at least one option", i+1)
	}
	
	// Check for opening brace
	if !strings.Contains(line, "{") {
		return i, fmt.Errorf("error (line %d): random statement must end with {", i+1)
	}
	
	// Randomly select one option
	randomIndex := rand.Intn(len(options))
	selectedOption := options[randomIndex]
	
	// Set the chosen variable
	vars["chosen"] = selectedOption
	
	// Parse random block
	randomBlock, nextI, err := parseBlock(lines, i+1)
	if err != nil {
		return i, fmt.Errorf("error (line %d): %s", i+1, err)
	}
	
	// Execute the random block
	if err := executeBlock(randomBlock, vars); err != nil {
		return i, fmt.Errorf("error in random block: %s", err)
	}
	
	return nextI, nil
}

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: blink <file>.blink")
		os.Exit(1)
	}
	filename := os.Args[1]
	source, err := os.ReadFile(filename)
	if err != nil {
		fmt.Fprintln(os.Stderr, "error reading file:", err)
		os.Exit(1)
	}
	vars := make(map[string]interface{})
	stopped := false // Track if execution is stopped

	lines := strings.Split(string(source), "\n")

	for i := 0; i < len(lines); i++ {
		line := strings.TrimSpace(lines[i])
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") || line == "}" || line == "} else {" || strings.Contains(line, "} else {") {
			continue
		}
		
		// Handle unstop command first (even when stopped)
		if line == "unstop" {
			if stopped {
				fmt.Println("un-stopped")
				stopped = false
			}
			continue
		}

		// If execution is stopped, skip all lines except unstop
		if stopped {
			continue
		}

		// Handle stop command
		if line == "stop" {
			fmt.Println("stopped")
			stopped = true
			continue
		}

		// Handle if statements (NO else support)
		if strings.HasPrefix(line, "if ") {
			// Parse and execute simple if statement
			newI, err := executeSimpleIf(lines, i, vars)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
			}
			i = newI - 1 // Adjust for loop increment
			continue
		}

		// Handle loop statements
		if strings.HasPrefix(line, "loop ") {
			// Parse and execute loop statement
			newI, err := executeLoop(lines, i, vars)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
			}
			i = newI - 1 // Adjust for loop increment
			continue
		}

		// Handle ask statements
		if strings.HasPrefix(line, "ask(") {
			// Parse and execute ask statement
			newI, err := executeAsk(lines, i, vars)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
			}
			i = newI - 1 // Adjust for loop increment
			continue
		}

		// Handle random statements
		if strings.HasPrefix(line, "random(") {
			// Parse and execute random statement
			newI, err := executeRandom(lines, i, vars)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
			}
			i = newI - 1 // Adjust for loop increment
			continue
		}

		// Execute regular line
		if err := executeLine(line, vars, i+1); err != nil {
			fmt.Fprintln(os.Stderr, err)
		}
	}
}

// ConditionalStatement represents an if/else-if/else statement
type ConditionalStatement struct {
	Condition string
	Block     []string
	Type      string // "if", "else-if", "else"
}

// executeSimpleIf executes an if statement with optional else support and returns the new line index
func executeSimpleIf(lines []string, startIdx int, vars map[string]interface{}) (int, error) {
	i := startIdx
	
	// Parse if statement
	line := strings.TrimSpace(lines[i])
	if !strings.HasPrefix(line, "if ") {
		return i, fmt.Errorf("expected if statement")
	}
	
	// Parse if condition
	ifPart := strings.TrimSpace(line[3:])
	if !strings.HasSuffix(ifPart, "{") {
		return i, fmt.Errorf("error (line %d): if statement must end with {", i+1)
	}
	condition := strings.TrimSpace(ifPart[:len(ifPart)-1])
	
	// Evaluate if condition
	result, err := evaluateCondition(condition, vars)
	if err != nil {
		return i, fmt.Errorf("error (line %d) evaluating condition '%s': %s", i+1, condition, err)
	}
	
	// Parse if block
	ifBlock, nextI, err := parseBlock(lines, i+1)
	if err != nil {
		return i, fmt.Errorf("error (line %d): %s", i+1, err)
	}
	
	// Check for else block - check the line where the block ended (nextI-1)
	var elseBlock []string
	finalI := nextI
	elseLineIdx := nextI - 1
	if elseLineIdx >= 0 && elseLineIdx < len(lines) {
		elseLine := strings.TrimSpace(lines[elseLineIdx])
		// Handle "} else {" on same line
		if strings.Contains(elseLine, "else {") {
			// Parse else block using specialized function
			elseBlock, finalI, err = parseElseBlock(lines, elseLineIdx)
			if err != nil {
				return i, fmt.Errorf("error (line %d): %s", elseLineIdx+1, err)
			}
		}
	}
	
	// Execute appropriate block based on condition
	if result {
		// Execute if block
		if err := executeBlock(ifBlock, vars); err != nil {
			return i, err
		}
	} else if len(elseBlock) > 0 {
		// Execute else block
		if err := executeBlock(elseBlock, vars); err != nil {
			return i, err
		}
	}
	
	return finalI, nil
}

// evaluateCondition evaluates a boolean condition
func evaluateCondition(condition string, vars map[string]interface{}) (bool, error) {
	condition = strings.TrimSpace(condition)
	
	// Try comparison first
	result, err := evaluateComparison(condition, vars)
	if err == nil {
		return result, nil
	}
	
	// Try expression evaluation
	condResult, err := evaluateExpression(condition, vars)
	if err != nil {
		return false, err
	}
	
	if boolVal, ok := condResult.(bool); ok {
		return boolVal, nil
	}
	
	return false, fmt.Errorf("condition must be boolean")
}

// parseBlock parses a block of code between braces
func parseBlock(lines []string, startIdx int) ([]string, int, error) {
	var block []string
	braceCount := 1
	i := startIdx
	
	for i < len(lines) && braceCount > 0 {
		line := strings.TrimSpace(lines[i])
		
		// Skip empty lines and comments
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") {
			i++
			continue
		}
		
		// Count braces in the line
		openBraces := strings.Count(line, "{")
		closeBraces := strings.Count(line, "}")
		
		// Add the line to the block before updating brace count
		// (except for standalone closing braces)
		if line != "}" {
			block = append(block, lines[i])
		}
		
		// Update brace count
		braceCount += openBraces - closeBraces
		
		// If we've closed all braces, we're done
		if braceCount == 0 {
			return block, i + 1, nil
		}
		
		i++
	}
	
	if braceCount > 0 {
		return nil, i, fmt.Errorf("unclosed block")
	}
	
	return block, i, nil
}

// parseElseBlock parses an else block starting from the "} else {" line
func parseElseBlock(lines []string, elseLineIdx int) ([]string, int, error) {
	var block []string
	braceCount := 1
	i := elseLineIdx + 1 // Start from the line after "} else {"
	
	for i < len(lines) && braceCount > 0 {
		line := strings.TrimSpace(lines[i])
		
		// Count braces more carefully - count each brace character
		for _, char := range line {
			if char == '{' {
				braceCount++
			} else if char == '}' {
				braceCount--
			}
		}
		
		// Check if we've reached the end of the block
		if braceCount == 0 {
			return block, i + 1, nil
		}
		
		if braceCount > 0 && line != "}" && !strings.Contains(line, "}") {
			block = append(block, lines[i])
		}
		
		i++
	}
	
	if braceCount > 0 {
		return nil, i, fmt.Errorf("unclosed else block")
	}
	
	return block, i, nil
}

// parseSingleBlock parses a single block between { and } and returns the block and new index
func parseSingleBlock(lines []string, startIdx int) ([]string, int) {
	var block []string
	braceCount := 1
	i := startIdx

	for i < len(lines) && braceCount > 0 {
		line := strings.TrimSpace(lines[i])

		if line == "{" {
			braceCount++
		} else if line == "}" {
			braceCount--
		}

		if braceCount > 0 {
			block = append(block, lines[i])
		}
		i++
	}

	return block, i
}
