package parser

import (
    "blink/lang/lexer"
    t "blink/lang/lexer"
)

type Parser struct {
    l        *lexer.Lexer
    curToken t.Token
    peekToken t.Token
}

func New(l *lexer.Lexer) *Parser {
    p := &Parser{l: l}
    p.nextToken()
    p.nextToken()
    return p
}

func (p *Parser) nextToken() {
    p.curToken = p.peekToken
    p.peekToken = p.l.NextToken()
}

func (p *Parser) ParseProgram() *Program {
    program := &Program{Statements: []Statement{}}

    for p.curToken.Type != t.EOF {
        stmt := p.parseStatement()
        if stmt != nil {
            program.Statements = append(program.Statements, stmt)
        }
        p.nextToken()
    }
    return program
}

func (p *Parser) parseStatement() Statement {
    switch p.curToken.Type {
    case t.IDENT, t.NUMBER:
        return p.parseAssignment()
    case "SAY":
        return p.parseSay()
    case "WAIT":
        return p.parseWait()
    default:
        return nil
    }
}

func (p *Parser) parseAssignment() *Assignment {
    name := p.curToken.Literal
    p.nextToken() // skip ident/number
    if p.curToken.Type != t.ASSIGN {
        return nil
    }
    p.nextToken() // skip '='
    value := p.curToken.Literal
    return &Assignment{Name: name, Value: value}
}

func (p *Parser) parseSay() *Say {
    p.nextToken() // skip "say"
    if p.curToken.Type != t.LPAREN {
        return nil
    }
    p.nextToken()
    arg := p.curToken.Literal
    p.nextToken()
    if p.curToken.Type != t.RPAREN {
        return nil
    }
    return &Say{Arg: arg}
}

func (p *Parser) parseWait() *Wait {
    p.nextToken() // skip "wait"
    duration := p.curToken.Literal
    return &Wait{Duration: duration}
}
