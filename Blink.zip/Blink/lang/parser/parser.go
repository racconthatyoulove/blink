package parser

import (
    "blink/lang/lexer"
    t "blink/lang/lexer"
)

type Parser struct {
    l        *lexer.Lexer
    curToken t.Token
    peekToken t.Token
}

func New(l *lexer.Lexer) *Parser {
    p := &Parser{l: l}
    p.nextToken()
    p.nextToken()
    return p
}

func (p *Parser) nextToken() {
    p.curToken = p.peekToken
    p.peekToken = p.l.NextToken()
}

func (p *Parser) ParseProgram() *Program {
    program := &Program{Statements: []Statement{}}

    for p.curToken.Type != t.EOF {
        stmt := p.parseStatement()
        if stmt != nil {
            program.Statements = append(program.Statements, stmt)
        }
        p.nextToken()
    }
    return program
}

func (p *Parser) parseStatement() Statement {
    switch p.curToken.Type {
    case t.IDENT, t.NUMBER:
        return p.parseAssignment()
    case "SAY":
        return p.parseSay()
    case "WAIT":
        return p.parseWait()
    case "REMOVE":
        return p.parseRemove()
    case "LOOP":
        return p.parseLoop()
    case "ASK":
        return p.parseAsk()
    case "RANDOM":
        return p.parseRandom()
    default:
        return nil
    }
}

func (p *Parser) parseAssignment() *Assignment {
    name := p.curToken.Literal
    p.nextToken() // skip ident/number
    if p.curToken.Type != t.ASSIGN {
        return nil
    }
    p.nextToken() // skip '='
    value := p.curToken.Literal
    return &Assignment{Name: name, Value: value}
}

func (p *Parser) parseSay() *Say {
    p.nextToken() // skip "say"
    if p.curToken.Type != t.LPAREN {
        return nil
    }
    p.nextToken()
    arg := p.curToken.Literal
    p.nextToken()
    if p.curToken.Type != t.RPAREN {
        return nil
    }
    return &Say{Arg: arg}
}

func (p *Parser) parseWait() *Wait {
    p.nextToken() // skip "wait"
    duration := p.curToken.Literal
    return &Wait{Duration: duration}
}

func (p *Parser) parseRemove() *Remove {
    p.nextToken() // skip "remove"
    if p.curToken.Type != t.ASSIGN {
        return nil
    }
    p.nextToken() // skip "="
    
    var items []string
    for p.curToken.Type != t.EOF && p.curToken.Type != t.NEWLINE {
        if p.curToken.Type == t.IDENT {
            items = append(items, p.curToken.Literal)
        }
        p.nextToken()
    }
    
    return &Remove{Items: items}
}

func (p *Parser) parseLoop() *Loop {
    p.nextToken() // skip "loop"
    count := p.curToken.Literal
    p.nextToken() // skip count
    
    if p.curToken.Type != t.LBRACE {
        return nil
    }
    p.nextToken() // skip "{"
    
    var body []Statement
    for p.curToken.Type != t.RBRACE && p.curToken.Type != t.EOF {
        stmt := p.parseStatement()
        if stmt != nil {
            body = append(body, stmt)
        }
        p.nextToken()
    }
    
    return &Loop{Count: count, Body: body}
}

func (p *Parser) parseAsk() *Ask {
    p.nextToken() // skip "ask"
    if p.curToken.Type != t.LPAREN {
        return nil
    }
    p.nextToken() // skip "("
    question := p.curToken.Literal
    p.nextToken() // skip question
    if p.curToken.Type != t.RPAREN {
        return nil
    }
    p.nextToken() // skip ")"
    
    if p.curToken.Type != t.LBRACE {
        return nil
    }
    p.nextToken() // skip "{"
    
    var body []Statement
    for p.curToken.Type != t.RBRACE && p.curToken.Type != t.EOF {
        stmt := p.parseStatement()
        if stmt != nil {
            body = append(body, stmt)
        }
        p.nextToken()
    }
    
    return &Ask{Question: question, Body: body}
}

func (p *Parser) parseRandom() *Random {
    p.nextToken() // skip "random"
    if p.curToken.Type != t.LPAREN {
        return nil
    }
    p.nextToken() // skip "("
    
    var options []string
    for p.curToken.Type != t.RPAREN && p.curToken.Type != t.EOF {
        if p.curToken.Type == t.IDENT || p.curToken.Type == t.NUMBER || p.curToken.Type == t.STRING {
            options = append(options, p.curToken.Literal)
        }
        p.nextToken()
        
        // Skip commas
        if p.curToken.Type == "," {
            p.nextToken()
        }
    }
    
    if p.curToken.Type != t.RPAREN {
        return nil
    }
    p.nextToken() // skip ")"
    
    if p.curToken.Type != t.LBRACE {
        return nil
    }
    p.nextToken() // skip "{"
    
    var body []Statement
    for p.curToken.Type != t.RBRACE && p.curToken.Type != t.EOF {
        stmt := p.parseStatement()
        if stmt != nil {
            body = append(body, stmt)
        }
        p.nextToken()
    }
    
    return &Random{Options: options, Body: body}
}
