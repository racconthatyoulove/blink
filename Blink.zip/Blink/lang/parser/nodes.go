package parser

import "strings"

type Node interface {
    TokenLiteral() string
}

type Statement interface {
    Node
    statementNode()
}

type Program struct {
    Statements []Statement
}

func (p *Program) TokenLiteral() string {
    if len(p.Statements) > 0 {
        return p.Statements[0].TokenLiteral()
    }
    return ""
}

type Assignment struct {
    Name  string
    Value string
}

func (a *Assignment) statementNode() {}
func (a *Assignment) TokenLiteral() string { return a.Name + " = " + a.Value }

type Say struct {
    Arg string
}

func (s *Say) statementNode() {}
func (s *Say) TokenLiteral() string { return "say(" + s.Arg + ")" }

type Wait struct {
    Duration string
}

func (w *Wait) statementNode() {}
func (w *Wait) TokenLiteral() string { return "wait " + w.Duration }

type Remove struct {
    Items []string
}

func (r *Remove) statementNode() {}
func (r *Remove) TokenLiteral() string { return "remove = " + strings.Join(r.Items, ", ") }

type Loop struct {
    Count string
    Body  []Statement
}

func (l *Loop) statementNode() {}
func (l *Loop) TokenLiteral() string { return "loop " + l.Count }
