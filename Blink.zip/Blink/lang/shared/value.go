package shared

type Value interface{}
