package runtime

import (
    "fmt"
    "strconv"
    "time"
    "blink/lang/env"
    "blink/lang/parser"
)

func Run(program *parser.Program) {
    scope := env.NewScope(nil)
    for _, stmt := range program.Statements {
        switch s := stmt.(type) {
        case *parser.Assignment:
            scope.Set(s.Name, s.Value)
        case *parser.Say:
            if val, ok := scope.Get(s.Arg); ok {
                fmt.Println(val)
            } else {
                fmt.Println(s.Arg)
            }
        case *parser.Wait:
            if duration, err := strconv.ParseFloat(s.Duration, 64); err == nil {
                time.Sleep(time.Duration(duration * float64(time.Second)))
            }
        case *parser.Remove:
            for _, item := range s.Items {
                scope.Remove(item)
            }
        case *parser.Loop:
            // Get loop count
            var loopCount int
            if val, ok := scope.Get(s.Count); ok {
                if floatVal, ok := val.(float64); ok {
                    loopCount = int(floatVal)
                } else {
                    fmt.Printf("Error: loop count variable '%s' is not a number\n", s.Count)
                    continue
                }
            } else {
                if count, err := strconv.Atoi(s.Count); err == nil {
                    loopCount = count
                } else {
                    fmt.Printf("Error: invalid loop count: %s\n", s.Count)
                    continue
                }
            }
            
            // Execute loop body
            for i := 0; i < loopCount; i++ {
                for _, bodyStmt := range s.Body {
                    // Execute each statement in the loop body
                    switch bs := bodyStmt.(type) {
                    case *parser.Assignment:
                        scope.Set(bs.Name, bs.Value)
                    case *parser.Say:
                        if val, ok := scope.Get(bs.Arg); ok {
                            fmt.Println(val)
                        } else {
                            fmt.Println(bs.Arg)
                        }
                    case *parser.Wait:
                        if duration, err := strconv.ParseFloat(bs.Duration, 64); err == nil {
                            time.Sleep(time.Duration(duration * float64(time.Second)))
                        }
                    }
                }
            }
        }
    }
}
