package runtime

import (
    "fmt"
    "strconv"
    "time"
    "blink/lang/env"
    "blink/lang/parser"
)

func Run(program *parser.Program) {
    scope := env.NewScope(nil)
    for _, stmt := range program.Statements {
        switch s := stmt.(type) {
        case *parser.Assignment:
            scope.Set(s.Name, s.Value)
        case *parser.Say:
            if val, ok := scope.Get(s.Arg); ok {
                fmt.Println(val)
            } else {
                fmt.Println(s.Arg)
            }
        case *parser.Wait:
            if duration, err := strconv.ParseFloat(s.Duration, 64); err == nil {
                time.Sleep(time.Duration(duration * float64(time.Second)))
            }
        }
    }
}
