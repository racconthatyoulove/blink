package main

import (
    "fmt"
    "os"
    "blink/lang/lexer"
    "blink/lang/parser"
    "blink/runtime"
)

func main() {
    if len(os.Args) < 2 {
        fmt.Println("Usage: blink <file.blink>")
        return
    }
    filename := os.Args[1]
    source, err := os.ReadFile(filename)
    if err != nil {
        panic(err)
    }

    l := lexer.New(string(source))
    p := parser.New(l)
    program := p.ParseProgram()

    runtime.Run(program)
}
