package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
	"regexp"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: blink <file>.blink")
		os.Exit(1)
	}
	filename := os.Args[1]
	source, err := os.ReadFile(filename)
	if err != nil {
		fmt.Fprintln(os.Stderr, "error reading file:", err)
		os.Exit(1)
	}
	vars := make(map[string]interface{})

	// iterate line by line to support comments starting with # or //
	scanner := bufio.NewScanner(strings.NewReader(string(source)))
	lineNo := 0
	for scanner.Scan() {
		lineNo++
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}
		// handle comments
		if strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") {
			continue
		}

		// assignment: name = value
		if strings.Contains(line, "=") {
			parts := strings.SplitN(line, "=", 2)
			name := strings.TrimSpace(parts[0])
			value := strings.TrimSpace(parts[1])

			// string literal
			if len(value) >= 2 && value[0] == '"' && value[len(value)-1] == '"' {
				unquoted := value[1:len(value)-1]
				vars[name] = unquoted
				continue
			}
			// number (integer)
			if i, err := strconv.Atoi(value); err == nil {
				vars[name] = i
				continue
			}
			// fallback: store as raw string (without quotes)
			vars[name] = value
			continue
		}

		// say(...) -- allow spaces like say(  "x"  )
		re := regexp.MustCompile(`^say\s*\(\s*(.*)\s*\)\s*$`)
		m := re.FindStringSubmatch(line)
		if len(m) == 2 {
			arg := m[1]
			// string literal
			if len(arg) >= 2 && arg[0] == '"' && arg[len(arg)-1] == '"' {
				fmt.Println(arg[1:len(arg)-1])
				continue
			}
			// identifier: must exist
			if val, ok := vars[arg]; ok {
				fmt.Println(val)
			} else {
				fmt.Fprintf(os.Stderr, "error (line %d): undefined variable %s\n", lineNo, arg)
			}
			continue
		}

		// unknown statement -> print error
		fmt.Fprintf(os.Stderr, "error (line %d): unknown statement: %s\n", lineNo, line)
	}
	if err := scanner.Err(); err != nil {
		fmt.Fprintln(os.Stderr, "error scanning file:", err)
	}
}
