package main

import (
	"fmt"
	"os"
	"path/filepath"
)

func main() {
	args := os.Args[1:]

	var files []string

	if len(args) == 0 {
		// default: every .blink file in current folder
		dir, err := os.Getwd()
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error: failed to get current directory:", err)
			os.Exit(1)
		}
		pattern := filepath.Join(dir, "*.blink")
		files, err = filepath.Glob(pattern)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error while searching for .blink files:", err)
			os.Exit(1)
		}
	} else {
		// if argument is an route
		input := args[0]
		stat, err := os.Stat(input)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error: %v\n", err)
			os.Exit(1)
		}

		if stat.IsDir() {
			// if it's a directory → run all .blink files in it
			pattern := filepath.Join(input, "*.blink")
			files, err = filepath.Glob(pattern)
			if err != nil {
				fmt.Fprintln(os.Stderr, "Error in finding .blink files:", err)
				os.Exit(1)
			}
		} else {
			// if it is a file → run just it
			files = []string{input}
		}
	}

	if len(files) == 0 {
		fmt.Println("Info: No .blink files found to run.")
		return
	}

	vars := map[string]Value{}
	for _, fname := range files {
		fmt.Println("=== Running:", filepath.Base(fname), "===")
		if err := runFile(fname, vars); err != nil {
			fmt.Fprintf(os.Stderr, "Error while processing %s: %v\n", fname, err)
		}
	}
}

