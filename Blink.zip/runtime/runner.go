package runtime

import (
    "fmt"
    "blink/lang/env"
    "blink/lang/parser"
)

func Run(program *parser.Program) {
    scope := env.NewScope(nil)
    for _, stmt := range program.Statements {
        switch s := stmt.(type) {
        case *parser.Assignment:
            scope.Set(s.Name, s.Value)
        case *parser.Say:
            if val, ok := scope.Get(s.Arg); ok {
                fmt.Println(val)
            } else {
                fmt.Println(s.Arg)
            }
        }
    }
}
