package main

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

func runFile(path string, vars map[string]Value) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	lineNo := 0
	for scanner.Scan() {
		lineNo++
		line := scanner.Text()

		// we cut '#' (comment on the end of the line)
		if idx := strings.Index(line, "#"); idx >= 0 {
			line = line[:idx]
		}

		// we remove spaces
		line = strings.TrimSpace(line)

		// ignore empty lines and comments
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}

		// assignment: "name = expr"
		if strings.Contains(line, "=") && !strings.HasPrefix(line, "say") {
			if err := handleAssignment(line, vars); err != nil {
				fmt.Fprintf(os.Stderr, "Error (file %s line %d): %v\n",
					filepath.Base(path), lineNo, err)
			}
			continue
		}

		// say(...)
		if strings.HasPrefix(line, "say") {
			if err := handleSay(line, vars); err != nil {
				fmt.Fprintf(os.Stderr, "Error (file %s line %d): %v\n",
					filepath.Base(path), lineNo, err)
			}
			continue
		}

		// unknown command
		fmt.Fprintf(os.Stderr, "Unknown command in %s line %d: %s\n",
			filepath.Base(path), lineNo, line)
	}

	return scanner.Err()
}
