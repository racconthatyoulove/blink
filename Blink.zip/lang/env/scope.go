package env

type Scope struct {
    store map[string]interface{}
    outer *Scope
}

func NewScope(outer *Scope) *Scope {
    return &Scope{store: make(map[string]interface{}), outer: outer}
}

func (s *Scope) Get(name string) (interface{}, bool) {
    val, ok := s.store[name]
    if !ok && s.outer != nil {
        return s.outer.Get(name)
    }
    return val, ok
}

func (s *Scope) Set(name string, val interface{}) interface{} {
    s.store[name] = val
    return val
}
