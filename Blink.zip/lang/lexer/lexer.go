package lexer

type Lexer struct {
	input        string
	position     int
	readPosition int
	ch           byte
}

func New(input string) *Lexer {
	l := &Lexer{input: input}
	l.readChar()
	return l
}

func (l *Lexer) readChar() {
	if l.readPosition >= len(l.input) {
		l.ch = 0
	} else {
		l.ch = l.input[l.readPosition]
	}
	l.position = l.readPosition
	l.readPosition++
}

func (l *Lexer) NextToken() Token {
	var tok Token

	l.skipWhitespace()

	switch l.ch {
	case '=':
		tok = NewToken(ASSIGN, string(l.ch))
	case '(':
		tok = NewToken(LPAREN, string(l.ch))
	case ')':
		tok = NewToken(RPAREN, string(l.ch))
	case '"':
		lit := l.readString()
		tok = NewToken(STRING, lit)
	case 0:
		tok = NewToken(EOF, "")
	default:
		if isLetter(l.ch) {
			lit := l.readIdentifier()
			tok = NewToken(LookupIdent(lit), lit)
			return tok
		} else if isDigit(l.ch) {
			return NewToken(NUMBER, l.readNumber())
		} else if l.ch == '\n' || l.ch == '\r' {
			tok = NewToken(NEWLINE, "\n")
		} else {
			tok = NewToken(ILLEGAL, string(l.ch))
		}
	}

	l.readChar()
	return tok
}

func (l *Lexer) skipWhitespace() {
	for l.ch == ' ' || l.ch == '\t' {
		l.readChar()
	}
}

func (l *Lexer) readIdentifier() string {
	pos := l.position
	for isLetter(l.ch) || isDigit(l.ch) {
		l.readChar()
	}
	return l.input[pos:l.position]
}

func (l *Lexer) readNumber() string {
	pos := l.position
	for isDigit(l.ch) {
		l.readChar()
	}
	return l.input[pos:l.position]
}

func (l *Lexer) readString() string {
	l.readChar()
	pos := l.position
	for l.ch != '"' && l.ch != 0 {
		l.readChar()
	}
	lit := l.input[pos:l.position]
	return lit
}

func isLetter(ch byte) bool {
	return 'a' <= ch && ch <= 'z' || 'A' <= ch && ch <= 'Z' || ch == '_'
}

func isDigit(ch byte) bool {
	return '0' <= ch && ch <= '9'
}
