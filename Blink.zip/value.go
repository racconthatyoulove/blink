package main

import "fmt"

// Value holds either a string or a number (float64)
type Value struct {
	IsNumber bool
	Num      float64
	Str      string
}

func (v Value) String() string {
	if v.IsNumber {
		// print as integer if whole, else as float
		if v.Num == float64(int64(v.Num)) {
			return fmt.Sprintf("%d", int64(v.Num))
		}
		return fmt.Sprintf("%g", v.Num)
	}
	return v.Str
}
